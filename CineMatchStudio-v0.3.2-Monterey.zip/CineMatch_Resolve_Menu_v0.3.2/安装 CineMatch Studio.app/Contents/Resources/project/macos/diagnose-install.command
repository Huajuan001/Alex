#!/bin/bash
# Read-only diagnosis of installation, apart from writing this report.
set -u
log_dir="$HOME/Library/Logs/CineMatchStudio"
mkdir -p "$log_dir" || exit 1
report="$log_dir/install-diagnostics-$(date '+%Y%m%d-%H%M%S').txt"
{
    printf 'CineMatch 安装诊断（不重装、不删除锁、不停止任何进程）\n'
    printf '时间：%s\n' "$(date)"
    printf '\n系统：\n'
    /usr/bin/sw_vers 2>&1 || true
    /usr/bin/uname -m 2>&1 || true
    printf '\n正在运行的安装器 PID（为空代表未找到，不列出其他进程参数）：\n'
    /usr/bin/pgrep -f '/macos/install[.]sh' || true
    printf '\n安装锁：\n'
    lock="$HOME/Library/Application Support/CineMatchStudio/.install-lock"
    if [ -d "$lock" ]; then
        printf '安装锁存在\n'
        if [ -f "$lock/pid" ]; then
            IFS= read -r owner < "$lock/pid" || owner=''
            case "$owner" in
                ''|*[!0-9]*) printf '锁 PID 无效/未知\n' ;;
                *)
                    if kill -0 "$owner" 2>/dev/null; then
                        printf '锁的进程仍运行：%s\n' "$owner"
                    else
                        printf '锁的进程已不存在：%s\n' "$owner"
                    fi
                    ;;
            esac
        else
            printf '旧版无 PID 记录的安装锁；本诊断不会删除它\n'
        fi
    else
        printf '没有安装锁\n'
    fi
    printf '\n安装日志末尾：\n'
    if [ -f "$log_dir/install.log" ]; then
        /usr/bin/tail -n 80 "$log_dir/install.log"
    else
        printf 'install.log 不存在；旧版在首次提示确认之后才创建日志\n'
    fi
    printf '\n安装入口日志末尾：\n'
    if [ -f "$log_dir/installer-launcher.log" ]; then
        /usr/bin/tail -n 40 "$log_dir/installer-launcher.log"
    else
        printf '没有入口日志（旧版没有此文件）\n'
    fi
    printf '\n网络检查（仅 HEAD，不下载运行环境或显示重定向令牌）：\n'
    for url in \
      'https://github.com/astral-sh/python-build-standalone/releases/download/20261013/cpython-3.11.17+20261013-x86_64-apple-darwin-install_only_stripped.tar.gz' \
      'https://pypi.org/simple/numpy/'; do
        if [ "$url" = 'https://pypi.org/simple/numpy/' ]; then
            printf 'PyPI: '
        else
            printf 'GitHub Python 运行环境: '
        fi
        /usr/bin/curl --head --location --silent --show-error --proto '=https' --tlsv1.2 \
            --connect-timeout 8 --max-time 20 --output /dev/null \
            --write-out 'HTTP %{http_code}; %{time_total} 秒\n' "$url" 2>&1 || true
    done
    printf '\n请将本报告内容发送给开发者。日志可能包含本机文件路径，请先检查再分享。\n'
} > "$report" 2>&1
cat "$report"
printf '\n报告保存在：%s\n' "$report"
/usr/bin/open -a TextEdit "$report" || /usr/bin/open "$report" || true
