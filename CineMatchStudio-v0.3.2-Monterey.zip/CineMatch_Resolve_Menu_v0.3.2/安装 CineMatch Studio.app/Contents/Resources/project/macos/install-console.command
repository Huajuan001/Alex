#!/bin/bash
# Finder opens this file in Terminal. No commands need to be typed.
set -u
script_dir="$(cd "$(dirname "$0")" && pwd)"
project_dir=''
staged=0
if [ -f "$script_dir/project/macos/install.sh" ]; then
    project_dir="$script_dir/project"
    if [ -f "$script_dir/.cinematch-staged" ]; then staged=1; fi
elif [ -f "$script_dir/安装 CineMatch Studio.app/Contents/Resources/project/macos/install.sh" ]; then
    project_dir="$script_dir/安装 CineMatch Studio.app/Contents/Resources/project"
fi
printf '\nCineMatch Studio v0.3.2 — 自动安装进度\n'
printf '无需输入命令。请保持窗口打开，安装结束会显示结果。\n\n'
if [ -z "$project_dir" ]; then
    printf '找不到安装文件。请完整解压 ZIP 后运行，保留安装器和其他文件的相对位置。\n' >&2
    exit 2
fi
if [ "$staged" = 0 ]; then
    printf '正在将安装资源保存到用户目录，避免临时隔离目录失效…\n'
    # shellcheck source=macos/stage-install.sh
    source "$project_dir/macos/stage-install.sh"
    if payload="$(stage_install_project "$project_dir" "$HOME/Library/Application Support/CineMatchStudio/installers")"; then
        exec /bin/bash "$payload/开始安装.command"
    else
        printf '准备安装文件失败。请重新完整解压 ZIP 后重试。\n' >&2
        exit 2
    fi
fi
if /bin/bash "$project_dir/macos/install.sh" --console; then
    printf '\n安装成功。重开 Resolve 后，从工作区 → 脚本菜单启动 CineMatch Studio。\n'
    status=0
else
    status=$?
    printf '\n安装未完成，退出码：%s。请将本窗口最后的错误文字或截图发给开发者。\n' "$status" >&2
fi
printf '\n日志位置：%s/Library/Logs/CineMatchStudio/install.log\n' "$HOME"
printf '安装进程已结束，可以关闭此窗口。\n'
exit "$status"
