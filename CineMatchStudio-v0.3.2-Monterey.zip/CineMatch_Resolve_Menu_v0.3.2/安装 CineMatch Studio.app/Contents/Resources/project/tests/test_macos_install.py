import importlib
import plistlib
from pathlib import Path
import subprocess
import sys

import pytest

from macos.install import (APP_MARKER, VERSION, build_application, check_existing,
                           default_paths, install_payload)

PROJECT = Path(__file__).resolve().parents[1]


def test_default_paths_are_user_scoped(tmp_path):
    base, scripts = default_paths(tmp_path)
    assert base.is_relative_to(tmp_path)
    assert scripts.is_relative_to(tmp_path)
    assert str(scripts).endswith('DaVinci Resolve/Fusion/Scripts/Utility')


def test_install_bundle_contents_and_reinstall_backup(tmp_path):
    base, scripts = default_paths(tmp_path)
    python = tmp_path/'Runtime With Spaces/bin/python'
    app, menu = install_payload(PROJECT, base, scripts, python)
    assert menu.read_text().startswith('-- CineMatch Studio menu launcher')
    assert (app/'Contents/Resources/cinematch-managed.txt').read_text() == APP_MARKER
    assert (app/'Contents/Resources/python-path').read_text().strip() == str(python)
    assert (app/'Contents/Resources/project/core/cube.py').is_file()
    assert (app/'Contents/Resources/project/ui/app.py').is_file()
    launcher = app/'Contents/MacOS/CineMatchStudio'
    assert launcher.stat().st_mode & 0o111
    with (app/'Contents/Info.plist').open('rb') as f:
        info = plistlib.load(f)
    assert info['CFBundleExecutable'] == launcher.name
    assert info['LSMinimumSystemVersion'] == '12.0'
    install_payload(PROJECT, base, scripts, python)
    backups = list((base/'backups').iterdir())
    assert len(backups) == 1
    assert (backups[0]/app.name).is_dir()
    assert (backups[0]/menu.name).is_file()
    assert not list(base.glob('.app-stage-*'))


@pytest.mark.parametrize('kind', ['script', 'app', 'symlink'])
def test_unrelated_user_files_preserved(tmp_path, kind):
    base, scripts = default_paths(tmp_path)
    base.mkdir(parents=True)
    scripts.mkdir(parents=True)
    app, menu = base/'CineMatch Studio.app', scripts/'CineMatch Studio.lua'
    if kind == 'script':
        menu.write_text('my own script')
    elif kind == 'app':
        app.mkdir()
        (app/'notes.txt').write_text('my app')
    else:
        menu.symlink_to(tmp_path/'elsewhere')
    with pytest.raises(RuntimeError):
        install_payload(PROJECT, base, scripts, Path(sys.executable))
    if kind == 'script':
        assert menu.read_text() == 'my own script'
    elif kind == 'app':
        assert (app/'notes.txt').read_text() == 'my app'
    else:
        assert menu.is_symlink()


def test_menu_write_failure_restores_previous_app(tmp_path, monkeypatch):
    import macos.install as installer
    base, scripts = default_paths(tmp_path)
    python = Path(sys.executable)
    app, menu = install_payload(PROJECT, base, scripts, python)
    sentinel = app/'user-notes.txt'
    sentinel.write_text('preserve me')
    menu_before = menu.read_bytes()
    def fail(*args):
        raise OSError('simulated file replacement failure')
    monkeypatch.setattr(installer.os, 'replace', fail)
    with pytest.raises(OSError, match='simulated'):
        install_payload(PROJECT, base, scripts, python)
    assert sentinel.read_text() == 'preserve me'
    assert menu.read_bytes() == menu_before


def test_installer_rejects_linux_without_touching_user_files():
    if sys.platform == 'darwin':
        pytest.skip('Linux-only guard test')
    result = subprocess.run([sys.executable, str(PROJECT/'macos/install.py'), '--project', str(PROJECT)],
                            capture_output=True, text=True)
    assert result.returncode == 2
    assert 'macOS only' in result.stderr


def test_launch_runs_shared_ui_with_external_output(tmp_path):
    """Run the real Bash app launcher, mock only the Python process."""
    app = tmp_path/'Application With Spaces.app'
    fake_python = tmp_path/'Python With Spaces'
    result_file = tmp_path/'captured.json'
    fake_python.write_text('#!'+sys.executable+'\n'
        'import json, os, pathlib, sys\n'
        f'pathlib.Path({str(result_file)!r}).write_text(json.dumps(dict(args=sys.argv[1:], cwd=os.getcwd(), '
        'output=os.environ.get("CINEMATCH_OUTPUT_DIR"), qt=os.environ.get("QT_PLUGIN_PATH"))))\n')
    fake_python.chmod(0o755)
    build_application(PROJECT, app, fake_python)
    # Logs must stay inside the test workspace; use a dedicated launcher copy.
    launch = app/'Contents/MacOS/CineMatchStudio'
    launch.write_text(launch.read_text().replace('log_dir="$HOME/Library/Logs/CineMatchStudio"',
                                                'log_dir="'+str(tmp_path/'logs')+'"'))
    import os, json
    result = subprocess.run(['bash', str(launch)], env={**os.environ, 'QT_PLUGIN_PATH': '/Resolve/Qt/plugins'},
                            capture_output=True, text=True)
    assert result.returncode == 0, result.stderr
    record = json.loads(result_file.read_text())
    assert record['args'][:2] == ['-I', '-c']
    assert record['cwd'] == str(app/'Contents/Resources/project')
    assert record['qt'] is None
    assert record['output'].endswith('/Pictures/CineMatch Studio')


@pytest.mark.parametrize('lua_module', ['lupa.lua51', 'lupa.lua54'])
@pytest.mark.parametrize('case', ['installed', 'missing', 'launch_failure'])
def test_lua_menu_entry_compatibility_and_quoting(lua_module, case):
    module = pytest.importorskip(lua_module)
    lua = module.LuaRuntime(unpack_returned_tuples=True)
    commands = []
    # Apostrophe, whitespace, and a shell substitution must remain literal.
    home = "/Users/O'Brien Studio/$(touch SHOULD_NOT_EXIST)"
    def execute(command):
        commands.append(command)
        return False if case == 'launch_failure' and command.startswith('/usr/bin/open') else 0
    lua.globals().os.getenv = lambda key: home
    lua.globals().os.execute = execute
    lua.globals().io.open = lambda *args: None if case == 'missing' else lua.eval('{close = function(self) end}')
    lua.execute((PROJECT/'macos/CineMatchStudio.lua').read_text())
    import shlex
    if case == 'missing':
        assert len(commands) == 1 and commands[0].startswith('/usr/bin/osascript')
    else:
        args = shlex.split(commands[0])
        assert args == ['/usr/bin/open', '-a', home+'/Library/Application Support/CineMatchStudio/CineMatch Studio.app']
        assert len(commands) == (2 if case == 'launch_failure' else 1)


def test_gui_default_output_can_be_outside_app(tmp_path, monkeypatch):
    pytest.importorskip('PySide6')
    import os
    os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
    from PySide6.QtWidgets import QApplication
    from ui.app import MainWindow
    app = QApplication.instance() or QApplication([])
    monkeypatch.setenv('CINEMATCH_OUTPUT_DIR', str(tmp_path/'Pictures'))
    window = MainWindow()
    assert window.output == str(tmp_path/'Pictures')
    window.close()


def test_backup_copy_failure_restores_app(tmp_path, monkeypatch):
    import macos.install as installer
    base, scripts = default_paths(tmp_path)
    app, menu = install_payload(PROJECT, base, scripts, Path(sys.executable))
    (app/'preserve.txt').write_text('saved')
    original_copy = installer.shutil.copy2
    def fail_menu_copy(source, dest, *args, **kwargs):
        if Path(source) == menu:
            raise OSError('simulated backup failure')
        return original_copy(source, dest, *args, **kwargs)
    monkeypatch.setattr(installer.shutil, 'copy2', fail_menu_copy)
    with pytest.raises(OSError, match='backup failure'):
        install_payload(PROJECT, base, scripts, Path(sys.executable))
    assert (app/'preserve.txt').read_text() == 'saved'
    assert menu.exists()


@pytest.mark.parametrize('valid', [True, False])
def test_runtime_checksum_rejects_modified_download(tmp_path, valid):
    import hashlib
    archive = tmp_path/'Runtime With Spaces.tar.gz'
    archive.write_bytes(b'test artifact')
    digest = hashlib.sha256(archive.read_bytes()).hexdigest() if valid else '0'*64
    command = 'source "$1"; verify_archive "$2" "$3"'
    result = subprocess.run(['bash', '-c', command, 'test', str(PROJECT/'macos/install.sh'), str(archive), digest],
                            capture_output=True, text=True)
    assert (result.returncode == 0) is valid
    assert archive.read_bytes() == b'test artifact'


def test_release_contains_executable_installer_and_hashed_lock(tmp_path):
    import zipfile
    from scripts.build_macos_menu import build
    archive = build(PROJECT, tmp_path)
    with zipfile.ZipFile(archive) as z:
        root = f'CineMatch_Resolve_Menu_v{VERSION}/安装 CineMatch Studio.app/Contents/'
        executable = z.getinfo(root+'MacOS/CineMatchInstaller')
        assert executable.external_attr >> 16 & 0o111
        info = plistlib.loads(z.read(root+'Info.plist'))
        assert info['CFBundleExecutable'] == 'CineMatchInstaller'
        assert info['LSMinimumSystemVersion'] == '12.0'
        assert b'--hash=sha256:' in z.read(root+'Resources/project/macos/plugin-requirements.lock')
        assert root+'Resources/project/resolve/inspect_local.py' in z.namelist()
        assert not any('.venv' in name or '__pycache__' in name for name in z.namelist())
    assert archive.with_suffix('.zip.sha256').is_file()


@pytest.mark.parametrize('legacy', ['0.2.0', '0.3.0', '0.3.1'])
def test_upgrading_legacy_preserves_old_version(tmp_path, legacy):
    base, scripts = default_paths(tmp_path)
    app, menu = install_payload(PROJECT, base, scripts, Path(sys.executable))
    (app/'Contents/Resources/cinematch-managed.txt').write_text(f'CineMatch Studio managed application v{legacy}\n')
    menu.write_text(f'-- CineMatch Studio menu launcher v{legacy}\n-- old version')
    install_payload(PROJECT, base, scripts, Path(sys.executable))
    assert (app/'Contents/Resources/cinematch-managed.txt').read_text() == APP_MARKER
    assert list((base/'backups').glob('*/CineMatch Studio.app'))
    assert f'v{VERSION}' in menu.read_text()
