# v0.3.1 · macOS Monterey / Intel 修复

## 确认的故障

v0.3.0 安装器和安装后的应用都通过共用 plist 生成器写入 `LSMinimumSystemVersion = 13.0`。这会在 macOS 12.7.6 上触发 Finder 禁止符号，尚未执行任何算法。即使绕过该清单，安装脚本还会拒绝系统主版本小于 13 的设备。

修复：两个应用清单统一 `12.0`；安装脚本接纳 12.0、12.7.6 和更新主版本，继续拒绝 macOS 11 及更早；应用构建号升到 4。保留 Intel 运行时下载选择、HTTPS 和固定哈希验证。没有要求用户升级系统或改变安全设置。

## 实际工件检查

为确认不是仅降低文本门槛，重新下载并验证了以下正式工件。PyPI wheel 与索引公布 SHA256 一致，Python 运行时与安装器固定官方校验值一致。解析 Mach-O 的 `LC_BUILD_VERSION` / `LC_VERSION_MIN_MACOSX`，SDK 字段不作为最低系统。

| 工件（Intel 切片） | 检查数量 | 最高最低系统声明 |
|---|---:|---|
| CPython 3.11.17 / 20261013 | 11 | 10.15 |
| NumPy 2.2.6 macOS 10.9 x86_64 wheel | 23 | 10.9 |
| Pillow 12.3.0 macOS 10.10 x86_64 wheel | 26 | 10.10 |
| PySide6 Essentials 6.8.3 universal2 wheel | 208 | 12.0 |
| shiboken6 6.8.3 universal2 wheel | 2 | 12.0 |

全部 270 个切片都有可识别的最低系统声明，无超出 12.0 的目标。Intel 头部均为通用 x86_64 subtype 3，没有 Haswell 专用 subtype 8；这仅核对头部，不等于逐条 CPU 指令审计。tifffile 为纯 Python wheel，不包含 Mach-O。

完整 JSON 见 [MONTEREY_INTEL_AUDIT.json](MONTEREY_INTEL_AUDIT.json)。审计工具可复现：

```bash
python -m scripts.audit_macos_artifacts /path/to/*.whl /path/to/runtime.tar.gz --output report.json
```

## 验证边界与本机步骤

117 项自动测试通过，含 Monterey 安装判定、plist 一致性、升级备份以及原有算法/界面测试；ShellCheck 通过。但云端为 Linux，未执行 macOS 动态加载、Gatekeeper、LaunchServices、旧 Xeon 指令集或实际 Resolve。安装器被系统允许启动后若仍有依赖加载问题，需要本机日志继续排查。

重新下载 v0.3.1，使用新解压目录里的安装器；不要再次运行旧 v0.3.0。Monterey 如果提示未认证开发者，使用系统提供的右键“打开”或“系统偏好设置 → 安全性与隐私 → 通用”打开选项，无需关闭系统安全保护。安装结束后重开 Resolve，从脚本菜单启动。

CineMatch 工具的 macOS 12 下限不意味着任意 Resolve 版本也支持 macOS 12 / 2013 Mac Pro。需确认本机实际 Resolve 版本和其官方系统/硬件支持范围；本修复未使用未经核验的 Resolve API。
