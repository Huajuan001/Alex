"""Read Mach-O minimum deployment targets without executing Mac binaries.

This is a static artifact check, not macOS or Resolve runtime validation.
"""
import argparse
import json
from pathlib import Path
import struct
import tarfile
import zipfile

ARCHES = {0x01000007: 'x86_64', 0x0100000C: 'arm64'}
THIN = {b'\xcf\xfa\xed\xfe': ('<', 32), b'\xfe\xed\xfa\xcf': ('>', 32),
        b'\xce\xfa\xed\xfe': ('<', 28), b'\xfe\xed\xfa\xce': ('>', 28)}
FAT = {b'\xca\xfe\xba\xbe': ('>', False), b'\xbe\xba\xfe\xca': ('<', False),
       b'\xca\xfe\xba\xbf': ('>', True), b'\xbf\xba\xfe\xca': ('<', True)}
MAGICS = set(THIN) | set(FAT)


def decode_version(value):
    return (value >> 16, (value >> 8) & 255, value & 255)


def macho_targets(data):
    """Return macOS targets per slice. Fail closed on truncated headers."""
    data = memoryview(data)
    magic = bytes(data[:4])
    if magic in FAT:
        endian, wide = FAT[magic]
        count, = struct.unpack_from(endian+'I', data, 4)
        records = []
        fmt = endian+('IIQQII' if wide else 'IIIII')
        entry_size = struct.calcsize(fmt)
        for index in range(count):
            entry = struct.unpack_from(fmt, data, 8+index*entry_size)
            offset, size = entry[2:4]
            if offset+size > len(data):
                raise ValueError('Truncated universal binary')
            records.extend(macho_targets(data[offset:offset+size]))
        return records
    if magic not in THIN:
        return []
    endian, header_size = THIN[magic]
    cpu, subtype = struct.unpack_from(endian+'II', data, 4)
    count, commands_size = struct.unpack_from(endian+'II', data, 16)
    if header_size+commands_size > len(data):
        raise ValueError('Truncated Mach-O load commands')
    offset, targets = header_size, []
    for _ in range(count):
        cmd, size = struct.unpack_from(endian+'II', data, offset)
        if size < 8 or offset+size > header_size+commands_size:
            raise ValueError('Invalid Mach-O command size')
        if cmd == 0x24:  # LC_VERSION_MIN_MACOSX
            if size < 16:
                raise ValueError('Truncated macOS deployment command')
            version, = struct.unpack_from(endian+'I', data, offset+8)
            targets.append(decode_version(version))
        elif cmd == 0x32:  # LC_BUILD_VERSION
            if size < 24:
                raise ValueError('Truncated build version command')
            platform, version = struct.unpack_from(endian+'II', data, offset+8)
            if platform == 1:
                targets.append(decode_version(version))
        offset += size
    return [{'arch': ARCHES.get(cpu, hex(cpu)), 'cpu_subtype': subtype & 0x00ffffff,
             'minimum_macos': max(targets) if targets else None}]


def archive_targets(path):
    path = Path(path)
    records = []
    if path.suffix == '.whl':
        with zipfile.ZipFile(path) as z:
            for name in z.namelist():
                if name.endswith('/'):
                    continue
                with z.open(name) as f:
                    if f.read(4) not in MAGICS:
                        continue
                for target in macho_targets(z.read(name)):
                    records.append({'file': name, **target})
    else:
        with tarfile.open(path) as t:
            for member in t:
                if not member.isfile():
                    continue
                with t.extractfile(member) as f:
                    header = f.read(4)
                    if header not in MAGICS:
                        continue
                    data = header+f.read()
                for target in macho_targets(data):
                    records.append({'file': member.name, **target})
    return records


def audit(path, arch='x86_64', target=(12, 0, 0)):
    records = [r for r in archive_targets(path) if r['arch'] == arch]
    missing = [r['file'] for r in records if r['minimum_macos'] is None]
    incompatible = [r for r in records if r['minimum_macos'] and r['minimum_macos'] > target]
    return {'artifact': Path(path).name, 'architecture': arch, 'checked_slices': len(records),
            'cpu_subtypes': sorted({r['cpu_subtype'] for r in records}),
            'has_haswell_only_slices': any(r['arch'] == 'x86_64' and r['cpu_subtype'] == 8 for r in records),
            'maximum_minimum_macos': max((r['minimum_macos'] for r in records if r['minimum_macos']), default=None),
            'unknown_targets': missing, 'incompatible': incompatible,
            'compatible_deployment_targets': bool(records) and not missing and not incompatible,
            'note': 'Static deployment metadata only; not macOS execution, CPU ISA audit or Resolve validation.'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('artifacts', nargs='+', type=Path)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    reports = [audit(path) for path in args.artifacts]
    text = json.dumps(reports, indent=2)
    if args.output:
        args.output.write_text(text+'\n')
    print(text)
    return 0 if all(r['compatible_deployment_targets'] for r in reports) else 1


if __name__ == '__main__':
    raise SystemExit(main())
