"""Headless GUI integration; optional when only core dependencies are installed."""
import os
os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
import time
import numpy as np
import pytest
pytest.importorskip('PySide6')
from PySide6.QtWidgets import QApplication, QMessageBox
from ui.app import MainWindow
from core.images import save_image
from core.cube import read_cube

@pytest.fixture(scope='module')
def app():
    return QApplication.instance() or QApplication([])


def wait_until_done(app, window):
    deadline = time.monotonic()+15
    while window.busy and time.monotonic()<deadline:
        app.processEvents()
        time.sleep(.01)
    assert not window.busy, 'Background generation timed out'


def test_ui_background_export_and_wipe(app, tmp_path):
    src, ref = tmp_path/'source.png', tmp_path/'reference.png'
    rng = np.random.default_rng(3)
    save_image(rng.random((30, 40, 3)), src)
    save_image(rng.random((25, 35, 3))*.8, ref)
    w = MainWindow()
    w.source, w.reference, w.output = str(src), str(ref), str(tmp_path/'out')
    w.show()
    app.processEvents()
    assert not w.run_button.visibleRegion().isEmpty()
    w.strength.setValue(30)
    w.start_generation()
    assert not w.controls.isEnabled()
    assert not w.run_button.isEnabled()
    wait_until_done(app, w)
    assert w.controls.isEnabled()
    assert w.run_button.isEnabled()
    assert '已导出' in w.status.text()
    assert read_cube(tmp_path/'out/luts/CineMatch_Test_33.cube').shape == (33, 33, 33, 3)
    assert w.comparison.before is not None
    for position in [0, 50, 100]:
        w.set_wipe(position)
        app.processEvents()
        assert not w.comparison.grab().isNull()
    w.close()


def test_ui_error_restores_controls(app, tmp_path, monkeypatch):
    messages = []
    monkeypatch.setattr(QMessageBox, 'critical', lambda *args: messages.append(args[-1]))
    w = MainWindow()
    w.source = w.reference = str(tmp_path/'missing.png')
    w.start_generation()
    wait_until_done(app, w)
    assert '生成失败' in w.status.text()
    assert messages and w.controls.isEnabled()
    w.close()


def test_gui_can_save_diagnostics_without_terminal(app, tmp_path, monkeypatch):
    import json
    from PySide6.QtWidgets import QFileDialog
    import resolve.inspect_local as local_docs
    target = tmp_path/'diagnostics.json'
    doc_root = tmp_path/'Developer'
    doc_root.mkdir()
    (doc_root/'README.txt').write_text('ExportCurrentFrameAsStill(path)\nLocal documentation fixture')
    monkeypatch.setattr(local_docs, 'DEFAULT_ROOTS', [doc_root])
    monkeypatch.setattr(QFileDialog, 'getSaveFileName', lambda *args: (str(target), 'JSON'))
    w = MainWindow()
    w.save_diagnostics()
    report = json.loads(target.read_text())
    assert report['api_verified'] is False
    assert report['locations'][0]['candidate_documentation_excerpts']
    assert '诊断已保存' in w.status.text()
    w.close()


def test_ui_dwg_generation_disables_srgb_brightness(app, tmp_path):
    import json
    from core.dwg_images import save_dwg
    from core.color_spaces import intermediate_encode, dwg_to_display
    from core.cube import sample_transform, apply_lut
    raw = intermediate_encode(np.repeat(np.geomspace(.002, 16, 120).reshape(10, 12, 1), 3, axis=-1))
    source, ref = tmp_path/'source.tiff', tmp_path/'reference.png'
    save_dwg(raw, source)
    save_image(apply_lut(raw, sample_transform(dwg_to_display))*.9, ref)
    w = MainWindow()
    w.options['brightness'].setValue(.1)
    w.mode.setCurrentIndex(1)
    assert not w.options['brightness'].isEnabled()
    assert w.options['brightness'].value() == 0
    assert w.exposure.isEnabled()
    w.source, w.reference, w.output = str(source), str(ref), str(tmp_path/'dwg')
    w.exposure.setValue(.2)
    w.start_generation()
    wait_until_done(app, w)
    assert '已导出' in w.status.text()
    assert w.comparison.before is not None
    assert json.loads((tmp_path/'dwg/manifest.json').read_text())['mode'] == 'dwg'
    w.mode.setCurrentIndex(0)
    assert not w.exposure.isEnabled() and w.exposure.value() == 0
    assert w.options['brightness'].isEnabled()
    w.close()


def test_workspace_drag_views_and_reset(app):
    from PySide6.QtCore import Qt, QPoint
    from PySide6.QtTest import QTest
    from ui.app import pixmap
    w = MainWindow()
    w.resize(1000, 680)
    w.show()
    app.processEvents()
    before = np.zeros((90, 160, 3))
    after = np.ones((90, 160, 3))
    w.comparison.set_images(pixmap(before), pixmap(after))
    rect = w.comparison.image_rect()
    QTest.mouseClick(w.comparison, Qt.MouseButton.LeftButton,
                     pos=QPoint(rect.left()+rect.width()*3//4, rect.center().y()))
    assert abs(w.comparison.position-75) <= 1
    assert w.wipe.value() == w.comparison.position
    for mode in ['before', 'after', 'split']:
        w.view_buttons[mode].click()
        assert w.comparison.view_mode == mode
    w.parameter_sliders['contrast'].setValue(125)
    assert w.options['contrast'].value() == 1.25
    w.options['saturation'].setValue(.65)
    assert w.parameter_sliders['saturation'].value() == 65
    w.strength.setValue(30)
    w.reset_button.click()
    assert w.strength.value() == 70
    assert w.options['contrast'].value() == w.options['saturation'].value() == 1
    assert not w.run_button.visibleRegion().isEmpty()
    assert not w.choose_output_button.visibleRegion().isEmpty()
    w.close()


def test_asset_selection_loads_preview_without_generation(app, tmp_path, monkeypatch):
    from PySide6.QtWidgets import QFileDialog
    source = tmp_path/'selected.png'
    save_image(np.full((40, 80, 3), .4), source)
    monkeypatch.setattr(QFileDialog, 'getOpenFileName', lambda *args: (str(source), ''))
    w = MainWindow()
    w.choose_image('source')
    deadline = time.monotonic()+5
    while w._thumb_workers and time.monotonic() < deadline:
        app.processEvents()
        time.sleep(.01)
    assert not w._thumb_workers
    assert w.comparison.before is not None
    assert w.comparison.after is None
    assert w.source_label.text() == source.name
    assert not w.asset_previews['source'].pixmap().isNull()
    assert w.last_paths is None
    # Old async deliveries must not replace the current selection.
    current = w.comparison.before.cacheKey()
    w.thumbnail_finished((('source', str(source), 'srgb', 0), np.ones((4, 4, 3)), None))
    assert w.comparison.before.cacheKey() == current
    w.close()
