"""Reproduce loss of the transient resource path after dependencies finish."""
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile
import pytest
from macos.install import install_payload, validate_project
from scripts.build_macos_menu import build

PROJECT = Path(__file__).resolve().parents[1]


def copy_project(destination):
    for name in ('macos', 'core', 'ui', 'resolve'):
        shutil.copytree(PROJECT/name, destination/name,
                        ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))


def stage(source, root):
    command = 'source "$1"; stage_install_project "$2" "$3"'
    return subprocess.run(['bash', '-c', command, 'test', str(PROJECT/'macos/stage-install.sh'),
                           str(source), str(root)], capture_output=True, text=True)


def test_apptranslocation_disappears_after_staging(tmp_path):
    transient = tmp_path/'AppTranslocation/uuid/d/安装 CineMatch Studio.app/Contents/Resources/project'
    copy_project(transient)
    result = stage(transient, tmp_path/'Library/Application Support/CineMatchStudio/installers')
    assert result.returncode == 0, result.stderr
    persisted = Path(result.stdout.strip())
    assert persisted.is_relative_to(tmp_path/'Library')
    assert (persisted/'.cinematch-staged').is_file()
    # Exactly the user's failure: the old AppTranslocation source disappears
    # before build_application attempts to copy macos/launch-app.sh.
    shutil.rmtree(tmp_path/'AppTranslocation')
    app, menu = install_payload(persisted/'project', tmp_path/'Installed', tmp_path/'Scripts', Path(sys.executable))
    assert (app/'Contents/MacOS/CineMatchStudio').is_file()
    assert (app/'Contents/Resources/project/core/cube.py').is_file()
    assert menu.is_file()
    assert (persisted/'开始安装.command').is_file()


def test_incomplete_source_rejected_before_download_or_app_changes(tmp_path):
    source = tmp_path/'source'
    copy_project(source)
    (source/'macos/launch-app.sh').unlink()
    result = stage(source, tmp_path/'persistent')
    assert result.returncode != 0
    assert 'macos/launch-app.sh' in result.stderr
    assert not (tmp_path/'persistent').exists()
    with pytest.raises(RuntimeError, match='before setup'):
        validate_project(source)
    with pytest.raises(RuntimeError):
        install_payload(source, tmp_path/'Installed', tmp_path/'Scripts', Path(sys.executable))
    assert not (tmp_path/'Installed').exists()


@pytest.mark.parametrize('status', [0, 7])
def test_console_wrapper_shows_output_and_preserves_exit_code(tmp_path, status):
    root = tmp_path/'Staged With Spaces'
    project = root/'project/macos'
    project.mkdir(parents=True)
    (root/'.cinematch-staged').write_text('fixture')
    (project/'install.sh').write_text('#!/bin/bash\n[ "$1" = --console ] || exit 99\nprintf "VISIBLE INSTALL PROGRESS\\n"\nexit '+str(status)+'\n')
    entry = root/'开始安装.command'
    shutil.copyfile(PROJECT/'macos/install-console.command', entry)
    result = subprocess.run(['bash', str(entry)], capture_output=True, text=True)
    assert result.returncode == status
    assert 'VISIBLE INSTALL PROGRESS' in result.stdout
    assert ('安装成功' in result.stdout) is (status == 0)
    if status:
        assert '退出码：7' in result.stderr


def test_failure_cleanup_preserves_payload_and_other_files(tmp_path):
    (tmp_path/'download').mkdir()
    (tmp_path/'download/file').write_text('this download only')
    (tmp_path/'lock').mkdir()
    (tmp_path/'lock/pid').write_text('123')
    (tmp_path/'persistent-payload').mkdir()
    (tmp_path/'persistent-payload/source').write_text('keep')
    command = '''source "$1"
cinematch_stage_dir="$2/download"
cinematch_lock_dir="$2/lock"
cinematch_have_lock=1
cinematch_phase='assemble application'
cinematch_log_dir="$2/logs"
finish_install 7
'''
    result = subprocess.run(['bash', '-c', command, 'test', str(PROJECT/'macos/install.sh'), str(tmp_path)],
                            capture_output=True, text=True)
    assert '退出码 7' in result.stderr
    assert not (tmp_path/'download').exists()
    assert not (tmp_path/'lock').exists()
    assert (tmp_path/'persistent-payload/source').read_text() == 'keep'


def test_release_has_visible_console_and_persisting_app_entry(tmp_path):
    archive = build(PROJECT, tmp_path)
    with zipfile.ZipFile(archive) as z:
        root = 'CineMatch_Resolve_Menu_v0.4.0/'
        for name in ['显示安装进度.command','查看安装诊断.command']:
            assert z.getinfo(root+name).external_attr >> 16 & 0o111
        app_entry = root+'安装 CineMatch Studio.app/Contents/MacOS/CineMatchInstaller'
        code = z.read(app_entry).decode()
        assert code.index('stage_install_project') < code.index('/usr/bin/open -a Terminal')
        assert '"$payload/开始安装.command"' in code
        assert root+'安装 CineMatch Studio.app/Contents/Resources/project/macos/launch-app.sh' in z.namelist()


def test_app_entry_records_early_resource_error(tmp_path):
    app = tmp_path/'Installer.app/Contents'
    (app/'MacOS').mkdir(parents=True)
    (app/'Resources').mkdir()
    entry = app/'MacOS/Installer'
    # Mock only the system dialog and log destination; keep resource discovery
    # and error handling in the shipped launcher unchanged.
    dialog = tmp_path/'fake-osascript'
    dialog.write_text('#!/bin/bash\ncat >/dev/null\nexit 0\n')
    dialog.chmod(0o755)
    text = (PROJECT/'macos/installer-launcher.sh').read_text()
    text = text.replace('log_dir="$HOME/Library/Logs/CineMatchStudio"', 'log_dir="'+str(tmp_path/'logs')+'"')
    text = text.replace('/usr/bin/osascript', str(dialog))
    entry.write_text(text)
    result = subprocess.run(['bash', str(entry)], capture_output=True, text=True)
    assert result.returncode == 1
    assert 'Missing staging helper' in (tmp_path/'logs/installer-launcher.log').read_text()
