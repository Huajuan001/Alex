# CineMatch Studio V1 · v0.4.0

电影参考图驱动的色彩匹配原型。支持前后预览、33³ `.cube` 导出和从 Resolve 脚本菜单启动的 PySide6 窗口。当前是全局统计匹配，不是专业电影风格迁移，也没有语义肤色保护、局部遮罩或跟踪。

## 普通用户：安装后从 Resolve 菜单启动

下载 `CineMatch_Resolve_Menu_v0.4.0.zip`，完整解压后双击“显示安装进度.command”。它会自动执行安装并显示进度，无需输入命令；也可打开“安装 CineMatch Studio.app”，它会自动准备资源并打开进度窗口。安装器会先把资源固定保存到用户目录，再准备独立运行环境，完成后重开 Resolve，从「工作区 → 脚本 → CineMatch Studio」启动（可能分组在 Utility）。无需手动安装 Python 或终端命令；macOS 12 Monterey 及以上，Intel / Apple Silicon。未签名/公证，首次打开可能需要系统提供的“仍要打开”流程。

用户已确认 Monterey / Resolve 19.1 上可以使用；新版界面仍需本机查看，Resolve LUT 输出一致性尚待逐像素验收。当前帧导出和 LUT 节点加载仍采用手动流程。详细说明见 [macos/README.md](macos/README.md)。

v0.3.1 已修复最低系统门槛；v0.3.2 修复 AppTranslocation 临时资源路径依赖、添加可见安装进度与诊断入口。安装器、应用清单及安装脚本统一为 macOS 12.0。已对实际 Intel 依赖进行静态部署版本检查；用户已确认 macOS 12.7.6 可用。详情见 [MONTEREY_COMPATIBILITY.md](docs/MONTEREY_COMPATIBILITY.md)。这不改变 Resolve 自身的版本/系统/硬件要求。

## v0.4.0 界面更新

中性深灰工作区、大幅画面对比、并排素材卡片和右侧参数栏。支持拖动分割线、原图/分割/结果切换、强度预设、滑杆数值同步和参数重置。小窗口参数区可滚动，导出操作固定可见。匹配算法、33³ LUT 导出和依赖锁文件不变，升级复用现有环境。

## 两种工作模式

| 模式 | 源图 | 参考图 | 调色 LUT 输入/输出与节点位置 |
|---|---|---|---|
| 显示参考 sRGB | 普通 8-bit RGB 图片，有 ICC 转 sRGB，无 ICC 按 sRGB 解释 | sRGB 图片 | sRGB → sRGB，仅用于同编码显示节点，不可直接套到 Log / DWG |
| DWG / Intermediate（实验） | 真正的 DWG/Intermediate 全范围 RGB16/float TIFF；开发可用 float NPY | sRGB 图片 | DWG / Intermediate → 同空间，放在输出显示变换之前；原生相机 Log 先正确转换到 DWG |

DWG 模式新增场景线性曝光、受约束对比度、冷暖和饱和度，保留高于显示白的 HDR 值；LUT 域仍限定编码 0..1，不支持负码值或超范围码值。不能根据扩展名自动检测源图色彩空间，也不把已渲染截图当作原始 DWG。

**DWG 预览使用 CineMatch 自有显示变换，与 Resolve DRT 不同。** 同时导出调色 LUT 和独立的诊断显示 View LUT；实际节点顺序、文件区分和逐像素验收见 [DWG_WORKFLOW.md](docs/DWG_WORKFLOW.md)。普通 Rec.709 Gamma 2.4 也不能直接当 sRGB。

下载包的“DWG 示例”包含真正编码为 DWG 的程序校准图，可先试跑，不代表真实电影画面质量测试。

## 开发者运行

目标 Python 3.11，在项目根目录：

```bash
python3.11 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements-ui.txt
python -m pytest -q
python -m ui.app
```

仅 CLI 安装 `requirements.txt` 即可。开发验证的 Colour Science 和 Lua 测试另装 `requirements-dev.txt`；不进入用户插件依赖。未安装可选依赖时相关测试会跳过。完整测试记录见 [STATUS.md](docs/STATUS.md)。

```bash
# 原显示 sRGB 路径
python -m core.lut_generator --source source.png --reference reference.png --strength .7 --output output/srgb
# DWG 路径，源图必须已编码为 DWG/Intermediate，非相机原生 Log
python -m core.lut_generator --mode dwg --source source_dwg.tiff --reference reference.png \
  --exposure .5 --strength .7 --output output/dwg
# 合成示例（30/70/100%），不会抓取或使用外部电影截图
python -m scripts.make_demo
python -m scripts.make_dwg_demo
```

`--contrast 0.5..1.5`、`--temperature -1..1`（正为暖）、`--saturation 0..2` 两种模式均可用。`--brightness -0.25..0.25` 只用于 sRGB 编码偏移；DWG 使用 `--exposure -4..4` 档。强度 0 会旁通调色控制。

结果在 `previews` / `luts`，DWG 另有 `graded` 浮点 TIFF；`manifest.json` 记录空间、参数、插值及使用位置。同目录同名结果会覆盖，建议每镜头/强度选不同输出目录。输入与输出冲突时拒绝执行。输出保留原尺寸，完整帧需要内存，大静帧可先缩小；统计拟合使用最长边至多 1200 的样本。预览先写出再回读 LUT，用四面体插值评估实际文件。

界面改变参数/模式后需点击生成，错误时保留上次成功预览并提示。可点击“保存 Resolve 诊断信息”收集本机开发文档路径/相关条目，不调用 API、不修改项目。源图与参考图可不同尺寸。
