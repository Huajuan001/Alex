"""CineMatch's Qt Widgets workspace; processing and thumbnail decoding are threaded."""
import sys
import os
import json
from pathlib import Path
import numpy as np
from PySide6.QtCore import Qt, QObject, Signal, QRunnable, QThreadPool, QRect, QRectF, QUrl
from PySide6.QtGui import QImage, QPixmap, QPainter, QColor, QPen, QFont, QDesktopServices
from PySide6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QPushButton, QLabel, QFileDialog, QSlider, QComboBox, QScrollArea, QDoubleSpinBox,
    QMessageBox, QFrame, QSizePolicy, QButtonGroup, QProgressBar, QMenu, QAbstractSpinBox)
from core.images import load_image
from core.matching import MatchSettings
from core.lut_generator import generate
from .theme import apply_theme


def pixmap(rgb):
    data = np.ascontiguousarray(np.rint(rgb*255).astype('uint8'))
    h, w, _ = data.shape
    return QPixmap.fromImage(QImage(data.data, w, h, data.strides[0], QImage.Format.Format_RGB888).copy())


def label(text='', name=None):
    widget = QLabel(text)
    if name:
        widget.setObjectName(name)
    return widget


def button(text, callback=None, name=None):
    widget = QPushButton(text)
    widget.setCursor(Qt.CursorShape.PointingHandCursor)
    if name:
        widget.setObjectName(name)
    if callback:
        widget.clicked.connect(callback)
    return widget


def divider():
    frame = QFrame()
    frame.setObjectName('Divider')
    frame.setFixedHeight(1)
    return frame


class Comparison(QWidget):
    positionChanged = Signal(int)

    def __init__(self):
        super().__init__()
        self.before = self.after = None
        self.position = 50
        self.view_mode = 'split'
        self.setMinimumSize(300, 230)
        self.setMouseTracking(True)

    def image_rect(self):
        if self.before is None:
            return QRect()
        available = self.rect().adjusted(16, 32, -16, -28)
        scaled = self.before.size().scaled(available.size(), Qt.AspectRatioMode.KeepAspectRatio)
        return QRect(available.center().x()-scaled.width()//2,
                     available.center().y()-scaled.height()//2, scaled.width(), scaled.height())

    def set_images(self, before, after=None):
        self.before, self.after = before, after
        self.setCursor(Qt.CursorShape.SplitHCursor if after is not None else Qt.CursorShape.ArrowCursor)
        self.update()

    def set_view_mode(self, mode):
        self.view_mode = mode
        self.update()

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHints(QPainter.RenderHint.Antialiasing | QPainter.RenderHint.SmoothPixmapTransform)
        p.setPen(QPen(QColor('#303339'), 1))
        p.setBrush(QColor('#0e0f11'))
        p.drawRoundedRect(QRectF(self.rect()).adjusted(.5, .5, -.5, -.5), 10, 10)
        if self.before is None:
            center = self.rect().center()
            p.setPen(QPen(QColor('#57534c'), 1.4))
            x, y = center.x(), center.y()-36
            # Crop-frame glyph, drawn locally without an icon/font dependency.
            for sx, sy in [(-1, -1), (1, -1), (-1, 1), (1, 1)]:
                p.drawLine(x+sx*24, y+sy*17, x+sx*14, y+sy*17)
                p.drawLine(x+sx*24, y+sy*17, x+sx*24, y+sy*8)
            p.setFont(QFont(self.font().family(), 15))
            p.setPen(QColor('#c8c9cc'))
            p.drawText(self.rect().adjusted(0, 8, 0, 8), Qt.AlignmentFlag.AlignCenter, '每一个镜头，从参考开始')
            p.setFont(QFont(self.font().family(), 10))
            p.setPen(QColor('#767b85'))
            p.drawText(self.rect().adjusted(0, 65, 0, 65), Qt.AlignmentFlag.AlignCenter, '在下方载入源画面与参考图，生成你的匹配结果')
            return
        rect = self.image_rect()
        if self.after is None or self.view_mode == 'before':
            p.drawPixmap(rect, self.before)
        elif self.view_mode == 'after':
            p.drawPixmap(rect, self.after)
        else:
            p.drawPixmap(rect, self.after)
            split = rect.left()+round(rect.width()*self.position/100)
            p.save()
            p.setClipRect(QRect(rect.left(), rect.top(), split-rect.left(), rect.height()))
            p.drawPixmap(rect, self.before)
            p.restore()
            p.setPen(QPen(QColor('#d6b788'), 1))
            p.drawLine(split, rect.top(), split, rect.bottom())
            p.setBrush(QColor('#232529'))
            p.drawEllipse(QRectF(split-11, rect.center().y()-11, 22, 22))
            p.setPen(QPen(QColor('#e6d2b5'), 1))
            p.drawLine(split-3, rect.center().y()-4, split-3, rect.center().y()+4)
            p.drawLine(split+3, rect.center().y()-4, split+3, rect.center().y()+4)
        p.setFont(QFont(self.font().family(), 9))
        p.setPen(QColor('#9298a2'))
        left = '原始画面' if self.view_mode != 'after' else '匹配结果'
        p.drawText(self.rect().adjusted(16, 8, -16, -8), Qt.AlignmentFlag.AlignTop | Qt.AlignmentFlag.AlignLeft, left)
        if self.after is not None and self.view_mode == 'split':
            p.drawText(self.rect().adjusted(16, 8, -16, -8), Qt.AlignmentFlag.AlignTop | Qt.AlignmentFlag.AlignRight, '匹配结果')
        if self.after is None:
            p.drawText(self.rect().adjusted(16, 8, -16, -9), Qt.AlignmentFlag.AlignBottom | Qt.AlignmentFlag.AlignCenter, '源画面预览 · 等待匹配')

    def _move_split(self, event):
        if self.before is None or self.after is None or self.view_mode != 'split':
            return
        rect = self.image_rect()
        if rect.width():
            value = max(0, min(100, round(100*(event.position().x()-rect.left())/rect.width())))
            self.positionChanged.emit(value)

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self._move_split(event)

    def mouseMoveEvent(self, event):
        if event.buttons() & Qt.MouseButton.LeftButton:
            self._move_split(event)


class WorkerSignals(QObject):
    result = Signal(object)
    error = Signal(str)


class GenerateWorker(QRunnable):
    def __init__(self, source, reference, output, settings, mode='srgb', exposure=0):
        super().__init__()
        self.args = (source, reference, output, settings)
        self.mode, self.exposure = mode, exposure
        self.signals = WorkerSignals()

    def run(self):
        try:
            paths = generate(*self.args, mode=self.mode, exposure=self.exposure)
            self.signals.result.emit((paths, load_image(paths['before'], max_size=1200),
                                      load_image(paths['preview'], max_size=1200),
                                      load_image(self.args[1], max_size=320)))
        except Exception as exc:
            self.signals.error.emit(f'{type(exc).__name__}: {exc}')


class ThumbnailSignals(QObject):
    finished = Signal(object)


class ThumbnailWorker(QRunnable):
    def __init__(self, kind, path, mode, token):
        super().__init__()
        self.key = (kind, path, mode, token)
        self.signals = ThumbnailSignals()

    def run(self):
        try:
            kind, path, mode, _ = self.key
            if kind == 'source' and mode == 'dwg':
                from core.dwg_images import load_dwg
                from core.color_spaces import dwg_to_display
                from core.cube import sample_transform, apply_lut
                rgb = apply_lut(load_dwg(path, max_size=1000), sample_transform(dwg_to_display))
            else:
                rgb = load_image(path, max_size=1000 if kind == 'source' else 400)
            self.signals.finished.emit((self.key, rgb, None))
        except Exception as exc:
            self.signals.finished.emit((self.key, None, str(exc)))


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        apply_theme(QApplication.instance())
        self.setWindowTitle('CineMatch Studio · 参考图色彩匹配')
        self.resize(1240, 800)
        self.setMinimumSize(1000, 680)
        self.source = self.reference = None
        self.output = str(Path(os.environ.get('CINEMATCH_OUTPUT_DIR', 'output')).expanduser().resolve())
        self.busy = False
        self.worker = None
        self.last_paths = None
        self._thumb_tokens = {'source': 0, 'reference': 0}
        self._thumb_workers = {}
        self.input_buttons = []
        self.asset_previews = {}
        root = QWidget()
        root.setObjectName('Root')
        self.setCentralWidget(root)
        layout = QVBoxLayout(root)
        layout.setContentsMargins(22, 18, 22, 12)
        layout.setSpacing(16)
        header = QHBoxLayout()
        mark = label('CM', 'BrandMark')
        mark.setFixedSize(36, 36)
        mark.setAlignment(Qt.AlignmentFlag.AlignCenter)
        header.addWidget(mark)
        brand = QVBoxLayout()
        brand.setSpacing(1)
        brand.addWidget(label('CineMatch Studio', 'Brand'))
        brand.addWidget(label('参考图色彩匹配  /  V1', 'Subtitle'))
        header.addLayout(brand)
        header.addStretch()
        self.space_badge = label('sRGB', 'Badge')
        header.addWidget(self.space_badge)
        more = button('···', name='Ghost')
        more.setFixedWidth(38)
        menu = QMenu(more)
        menu.addAction('保存 Resolve 诊断信息', self.save_diagnostics)
        menu.addAction('使用说明', self.show_help)
        more.setMenu(menu)
        header.addWidget(more)
        layout.addLayout(header)
        layout.addWidget(divider())
        body = QHBoxLayout()
        body.setSpacing(18)
        workspace = QVBoxLayout()
        workspace.setSpacing(12)
        viewer_header = QHBoxLayout()
        viewer_header.addWidget(label('画面对比', 'SectionTitle'))
        self.state_chip = label('等待载入', 'Muted')
        viewer_header.addWidget(self.state_chip)
        viewer_header.addStretch()
        self.view_buttons = {}
        self.view_group = QButtonGroup(self)
        for text, mode in [('分割', 'split'), ('原图', 'before'), ('结果', 'after')]:
            b = button(text, name='Segment')
            b.setCheckable(True)
            b.setChecked(mode == 'split')
            b.clicked.connect(lambda checked=False, value=mode: self.comparison.set_view_mode(value))
            self.view_group.addButton(b)
            self.view_buttons[mode] = b
            viewer_header.addWidget(b)
        workspace.addLayout(viewer_header)
        self.comparison = Comparison()
        self.comparison.positionChanged.connect(self.set_wipe)
        workspace.addWidget(self.comparison, 1)
        wipe_row = QHBoxLayout()
        wipe_row.addWidget(label('原图', 'Muted'))
        self.wipe = QSlider(Qt.Orientation.Horizontal)
        self.wipe.setRange(0, 100)
        self.wipe.setValue(50)
        self.wipe.valueChanged.connect(self.set_wipe)
        wipe_row.addWidget(self.wipe, 1)
        wipe_row.addWidget(label('匹配结果', 'Muted'))
        workspace.addLayout(wipe_row)
        self.view_note = label('拖动画面中的分割线，查看前后变化', 'Hint')
        workspace.addWidget(self.view_note)
        assets = QHBoxLayout()
        assets.setSpacing(12)
        assets.addWidget(self.make_asset_card('source', '源画面', '选择画面'))
        assets.addWidget(self.make_asset_card('reference', '电影参考图', '选择参考'))
        workspace.addLayout(assets)
        body.addLayout(workspace, 1)
        body.addWidget(self.make_sidebar())
        layout.addLayout(body, 1)
        self.progress = QProgressBar()
        self.progress.setRange(0, 0)
        self.progress.setTextVisible(False)
        self.progress.setFixedHeight(3)
        self.progress.hide()
        layout.addWidget(self.progress)
        footer = QHBoxLayout()
        self.status = label('选择源画面和参考图，开始色彩匹配。', 'Muted')
        self.status.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        self.status.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        footer.addWidget(self.status, 1)
        footer.addWidget(label('本地处理  ·  33³ LUT', 'Eyebrow'))
        layout.addLayout(footer)
        self.update_mode()

    def make_asset_card(self, kind, title, action):
        card = QFrame()
        card.setObjectName('AssetCard')
        card.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Fixed)
        row = QHBoxLayout(card)
        row.setContentsMargins(12, 12, 12, 12)
        row.setSpacing(12)
        thumb = label('SOURCE' if kind == 'source' else 'REFERENCE', 'Thumbnail')
        thumb.setAlignment(Qt.AlignmentFlag.AlignCenter)
        thumb.setFixedSize(92, 66)
        row.addWidget(thumb)
        self.asset_previews[kind] = thumb
        if kind == 'reference':
            self.reference_view = thumb
        details = QVBoxLayout()
        details.setSpacing(5)
        top = QHBoxLayout()
        top.addWidget(label(title, 'Eyebrow'))
        top.addStretch()
        choose = button(action, lambda checked=False, k=kind: self.choose_image(k), 'Ghost')
        choose.setStyleSheet('font-size: 11px; padding: 2px 0;')
        self.input_buttons.append(choose)
        top.addWidget(choose)
        details.addLayout(top)
        filename = label('尚未载入', 'Subtitle')
        filename.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        setattr(self, kind+'_label', filename)
        details.addWidget(filename)
        details.addWidget(label('原始素材' if kind == 'source' else '以此画面作为风格参考', 'Hint'))
        row.addLayout(details, 1)
        return card

    def make_sidebar(self):
        panel = QFrame()
        panel.setObjectName('Sidebar')
        panel.setFixedWidth(314)
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(17, 17, 17, 17)
        layout.setSpacing(14)
        title = QHBoxLayout()
        title.addWidget(label('匹配调整', 'SectionTitle'))
        title.addStretch()
        self.reset_button = button('重置', self.reset_settings, 'Ghost')
        title.addWidget(self.reset_button)
        layout.addLayout(title)
        self.controls = QWidget()
        controls = QVBoxLayout(self.controls)
        controls.setContentsMargins(0, 0, 6, 0)
        controls.setSpacing(12)
        controls.addWidget(label('工作空间', 'Eyebrow'))
        self.mode = QComboBox()
        self.mode.addItem('显示参考 sRGB', 'srgb')
        self.mode.addItem('DWG / Intermediate', 'dwg')
        self.mode.setMinimumHeight(34)
        controls.addWidget(self.mode)
        self.warning = label('', 'Warning')
        self.warning.setWordWrap(True)
        controls.addWidget(self.warning)
        controls.addWidget(divider())
        strength_row = QHBoxLayout()
        strength_row.addWidget(label('匹配强度'))
        strength_row.addStretch()
        self.strength_label = label('70%', 'Number')
        strength_row.addWidget(self.strength_label)
        controls.addLayout(strength_row)
        self.strength = QSlider(Qt.Orientation.Horizontal)
        self.strength.setRange(0, 100)
        self.strength.setValue(70)
        self.strength.valueChanged.connect(self.strength_changed)
        controls.addWidget(self.strength)
        presets = QHBoxLayout()
        for value, text in [(30, '轻度 30%'), (70, '平衡 70%'), (100, '完整 100%')]:
            presets.addWidget(button(text, lambda checked=False, v=value: self.strength.setValue(v), 'Preset'))
        controls.addLayout(presets)
        controls.addWidget(divider())
        controls.addWidget(label('色彩微调', 'Eyebrow'))
        self.options = {}
        self.parameter_rows = {}
        self.parameter_sliders = {}
        for name, title, lo, hi, default, step in [
                ('exposure', '曝光 / 档', -4, 4, 0, .1),
                ('brightness', '亮度偏移', -.25, .25, 0, .05),
                ('contrast', '对比度', .5, 1.5, 1, .05),
                ('temperature', '冷暖', -1, 1, 0, .05),
                ('saturation', '饱和度', 0, 2, 1, .05)]:
            row = QWidget()
            vertical = QVBoxLayout(row)
            vertical.setContentsMargins(0, 0, 0, 0)
            vertical.setSpacing(3)
            top = QHBoxLayout()
            top.addWidget(label(title))
            top.addStretch()
            spin = QDoubleSpinBox()
            spin.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.NoButtons)
            spin.setAlignment(Qt.AlignmentFlag.AlignRight)
            spin.setRange(lo, hi)
            spin.setSingleStep(step)
            spin.setValue(default)
            spin.setFixedWidth(68)
            top.addWidget(spin)
            vertical.addLayout(top)
            slider = QSlider(Qt.Orientation.Horizontal)
            slider.setRange(round(lo*100), round(hi*100))
            slider.setValue(round(default*100))
            spin.valueChanged.connect(lambda value, s=slider: s.setValue(round(value*100)))
            slider.valueChanged.connect(lambda value, s=spin: s.setValue(value/100))
            spin.valueChanged.connect(self.mark_stale)
            vertical.addWidget(slider)
            controls.addWidget(row)
            self.parameter_rows[name] = row
            self.parameter_sliders[name] = slider
            if name == 'exposure':
                self.exposure = spin
            else:
                self.options[name] = spin
        controls.addStretch()
        self.mode.currentIndexChanged.connect(self.update_mode)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        scroll.setWidget(self.controls)
        layout.addWidget(scroll, 1)
        layout.addWidget(divider())
        output_row = QHBoxLayout()
        output_row.addWidget(label('导出位置', 'Eyebrow'))
        output_row.addStretch()
        self.choose_output_button = button('更改', self.choose_output, 'Ghost')
        output_row.addWidget(self.choose_output_button)
        layout.addLayout(output_row)
        self.output_label = label(Path(self.output).name, 'Subtitle')
        self.output_label.setToolTip(self.output)
        self.output_label.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        layout.addWidget(self.output_label)
        self.run_button = button('生成并导出 LUT', self.start_generation, 'Primary')
        layout.addWidget(self.run_button)
        self.open_output_button = button('查看导出文件  ↗', self.open_output, 'Ghost')
        self.open_output_button.setEnabled(False)
        layout.addWidget(self.open_output_button)
        return panel

    def strength_changed(self, value):
        self.strength_label.setText(f'{value}%')
        self.mark_stale()

    def mark_stale(self, *_):
        if hasattr(self, 'status'):
            if self.last_paths:
                self.state_chip.setText('参数已修改 · 待生成')
            self.status.setText('参数或输入已更改，点击“生成并导出 LUT”更新结果。')

    def reset_settings(self):
        self.strength.setValue(70)
        self.exposure.setValue(0)
        for name, value in [('brightness', 0), ('contrast', 1), ('temperature', 0), ('saturation', 1)]:
            self.options[name].setValue(value)
        self.mark_stale()

    def update_mode(self):
        dwg = self.mode.currentData() == 'dwg'
        self.exposure.setEnabled(dwg)
        self.parameter_sliders['exposure'].setEnabled(dwg)
        self.options['brightness'].setEnabled(not dwg)
        self.parameter_sliders['brightness'].setEnabled(not dwg)
        self.parameter_rows['exposure'].setVisible(dwg)
        self.parameter_rows['brightness'].setVisible(not dwg)
        if dwg:
            self.options['brightness'].setValue(0)
            self.warning.setText('源图：DWG RGB16 / 浮点 TIFF\n参考图：sRGB\n调色 LUT 放在输出变换之前；相机 Log 先转换到 DWG。')
            self.space_badge.setText('DWG / Intermediate')
            self.view_note.setText('DWG 预览采用 CineMatch 显示变换，与 Resolve DRT 不同。')
        else:
            self.exposure.setValue(0)
            self.warning.setText('源图与参考图：显示参考 sRGB\n此模式 LUT 仅用于相同显示空间，不直接用于 Log / DWG。')
            self.space_badge.setText('显示 sRGB')
            self.view_note.setText('拖动分割线查看前后变化；修改参数后点击生成更新。')
        self.mark_stale()
        # A preview from another encoding must not remain under the new space label.
        self.comparison.set_images(None)
        for kind in ('source', 'reference'):
            if getattr(self, kind):
                self.load_thumbnail(kind)

    def choose_image(self, kind):
        filt = ('DWG raw RGB16/float (*.tif *.tiff *.npy)' if kind == 'source' and self.mode.currentData() == 'dwg'
                else 'Images (*.png *.jpg *.jpeg *.tif *.tiff *.bmp *.webp)')
        path, _ = QFileDialog.getOpenFileName(self, '选择源画面' if kind == 'source' else '选择参考图', '', filt)
        if not path:
            return
        setattr(self, kind, path)
        filename = getattr(self, kind+'_label')
        filename.setText(Path(path).name)
        filename.setToolTip(path)
        self.comparison.after = None
        self.comparison.update()
        self.state_chip.setText('载入画面…')
        self.mark_stale()
        self.load_thumbnail(kind)

    def load_thumbnail(self, kind):
        path = getattr(self, kind)
        self._thumb_tokens[kind] += 1
        token = self._thumb_tokens[kind]
        worker = ThumbnailWorker(kind, path, self.mode.currentData(), token)
        self._thumb_workers[(kind, token)] = worker
        worker.signals.finished.connect(self.thumbnail_finished)
        QThreadPool.globalInstance().start(worker)

    def thumbnail_finished(self, result):
        (kind, path, mode, token), rgb, error = result
        self._thumb_workers.pop((kind, token), None)
        if token != self._thumb_tokens[kind] or path != getattr(self, kind) or mode != self.mode.currentData() or self.busy:
            return
        if error:
            self.asset_previews[kind].setText('无法预览')
            self.asset_previews[kind].setToolTip(error)
            self.status.setText('预览读取失败：'+error)
            self.state_chip.setText('请检查输入')
            return
        image = pixmap(rgb)
        self.asset_previews[kind].setPixmap(image.scaled(90, 64, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation))
        if kind == 'source':
            self.comparison.set_images(image)
        self.state_chip.setText('待匹配')
        self.status.setText('图片已载入，点击生成完成匹配与 LUT 导出。')

    def choose_output(self):
        path = QFileDialog.getExistingDirectory(self, '选择输出目录', self.output)
        if path:
            self.output = path
            self.output_label.setText(Path(path).name)
            self.output_label.setToolTip(path)

    def open_output(self):
        if self.last_paths:
            folder = Path(self.last_paths['manifest']).parent
            QDesktopServices.openUrl(QUrl.fromLocalFile(str(folder.resolve())))

    def save_diagnostics(self):
        from resolve.inspect_local import inspect, DEFAULT_ROOTS
        path, _ = QFileDialog.getSaveFileName(self, '保存诊断信息', str(Path.home()/'Desktop/CineMatch_Resolve_Diagnostics.json'), 'JSON (*.json)')
        if not path:
            return
        try:
            report = inspect(DEFAULT_ROOTS, include_excerpts=True)
            Path(path).write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
            self.status.setText('诊断已保存：'+path+'。未调用 Resolve API。')
        except (OSError, ValueError) as exc:
            QMessageBox.warning(self, '诊断失败', str(exc))

    def show_help(self):
        QMessageBox.information(self, '使用说明',
            '1. 选择工作空间，再载入源画面与参考图。\n2. 调整匹配强度和色彩参数，点击生成。\n3. 拖动分割线对比，或切换原图 / 结果。\n4. 在导出目录取得 LUT、预览与参数记录。\n\n'
            'DWG 调色 LUT 放在输出变换前；View LUT 仅用于显示验证。\n这是全局统计原型，无语义肤色保护；源图不会被覆盖。')

    def set_wipe(self, value):
        self.comparison.position = value
        if self.wipe.value() != value:
            self.wipe.setValue(value)
        self.comparison.update()

    def set_busy(self, busy):
        self.busy = busy
        for control in [self.controls, self.run_button, self.reset_button, self.choose_output_button, *self.input_buttons]:
            control.setEnabled(not busy)
        self.run_button.setText('正在生成…' if busy else '生成并导出 LUT')
        self.progress.setVisible(busy)

    def start_generation(self):
        if self.busy:
            return
        if not self.source or not self.reference:
            QMessageBox.warning(self, '缺少图片', '请先选择源画面和参考图。')
            return
        for kind in self._thumb_tokens:
            self._thumb_tokens[kind] += 1
        self.set_busy(True)
        self.state_chip.setText('正在匹配…')
        self.status.setText('正在生成预览、33³ LUT 和参数记录，请稍候…')
        settings = MatchSettings(strength=self.strength.value()/100, **{name: spin.value() for name, spin in self.options.items()})
        self.worker = GenerateWorker(self.source, self.reference, self.output, settings, self.mode.currentData(), self.exposure.value())
        self.worker.signals.result.connect(self.show_result)
        self.worker.signals.error.connect(self.show_error)
        QThreadPool.globalInstance().start(self.worker)

    def show_result(self, result):
        paths, before, after, reference = result
        self.last_paths = paths
        self.comparison.set_images(pixmap(before), pixmap(after))
        for kind, rgb in [('source', before), ('reference', reference)]:
            self.asset_previews[kind].setPixmap(pixmap(rgb).scaled(90, 64, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation))
            path = getattr(self, kind)
            getattr(self, kind+'_label').setText(Path(path).name)
            getattr(self, kind+'_label').setToolTip(path)
        self.state_chip.setText(f'已生成 · {self.strength.value()}%')
        self.status.setText('已导出：'+str(paths['lut']))
        self.status.setToolTip(str(paths['lut']))
        self.open_output_button.setEnabled(True)
        self.set_busy(False)

    def show_error(self, error):
        self.set_busy(False)
        self.state_chip.setText('生成失败')
        self.status.setText('生成失败：'+error+'。保留上次成功结果。')
        self.status.setToolTip(error)
        QMessageBox.critical(self, '生成失败', error)

    def closeEvent(self, event):
        if self.busy:
            self.status.setText('正在保存输出，完成后即可关闭窗口。')
            event.ignore()
        else:
            event.accept()


def main():
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    return app.exec()


if __name__ == '__main__':
    raise SystemExit(main())
