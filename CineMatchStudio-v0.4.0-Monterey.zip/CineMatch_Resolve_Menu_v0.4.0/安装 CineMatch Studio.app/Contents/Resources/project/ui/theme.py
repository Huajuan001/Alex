"""Neutral, low-glare Qt Widgets theme. No image-color filters or GPU effects."""
from PySide6.QtGui import QColor, QPalette

STYLE = '''
QWidget { color: #e2e3e5; font-size: 13px; }
QMainWindow, QWidget#Root { background: #151618; }
QLabel { background: transparent; border: none; }
QLabel#BrandMark { background: #d5b17e; color: #171819; border-radius: 8px; font-weight: 700; font-size: 13px; }
QLabel#Brand { font-size: 22px; font-weight: 600; color: #f0f0f0; }
QLabel#Subtitle, QLabel#Hint, QLabel#Muted { color: #999ca3; font-size: 12px; }
QLabel#Eyebrow { color: #94979f; font-size: 11px; }
QLabel#SectionTitle { font-size: 16px; font-weight: 600; }
QLabel#Number { color: #dbb782; font-size: 15px; font-weight: 600; }
QLabel#Badge { border: 1px solid #41434a; color: #c0c3c9; background: #202226; border-radius: 11px; padding: 4px 10px; font-size: 11px; }
QLabel#Warning { background: #252528; border: 1px solid #37373b; border-radius: 7px; padding: 9px; color: #aeb0b6; font-size: 11px; }
QFrame#Sidebar { background: #1e2023; border: 1px solid #33363b; border-radius: 12px; }
QFrame#AssetCard { background: #1d1f22; border: 1px solid #34363c; border-radius: 9px; }
QLabel#Thumbnail { background: #121315; border: 1px solid #34363a; border-radius: 5px; color: #777c85; font-size: 11px; }
QFrame#Divider { background: #33363b; max-height: 1px; border: none; }
QPushButton { background: #2b2e33; border: 1px solid #3c3f45; border-radius: 6px; padding: 7px 12px; color: #d8dbe0; }
QPushButton:hover { background: #35393f; border-color: #555a63; }
QPushButton:pressed { background: #22252a; }
QPushButton:disabled { color: #62666d; background: #24262a; border-color: #303239; }
QPushButton#Primary { background: #d5b17e; color: #171819; border: none; font-size: 14px; font-weight: 600; min-height: 31px; border-radius: 7px; }
QPushButton#Primary:hover { background: #e2bf90; }
QPushButton#Primary:pressed { background: #bd9867; }
QPushButton#Primary:disabled { background: #3c3934; color: #817767; }
QPushButton#Ghost { border: none; background: transparent; color: #aeb2ba; padding: 5px 8px; }
QPushButton#Ghost:hover { background: #2b2e33; color: #f0f0f0; }
QPushButton#Segment { background: #1b1d20; border: 1px solid #34373d; color: #9297a0; padding: 5px 12px; }
QPushButton#Segment:checked { background: #35332f; color: #e5c59c; border-color: #665844; }
QPushButton#Preset { padding: 3px 7px; color: #b2b6be; font-size: 11px; }
QComboBox, QDoubleSpinBox { background: #17191c; border: 1px solid #3a3d43; border-radius: 5px; padding: 6px 8px; selection-background-color: #695740; }
QComboBox:hover, QDoubleSpinBox:hover { border-color: #66615a; }
QComboBox:focus, QDoubleSpinBox:focus { border-color: #b3946c; }
QComboBox:disabled, QDoubleSpinBox:disabled { color: #646871; border-color: #303339; }
QComboBox::drop-down { border: none; width: 22px; }
QComboBox QAbstractItemView { background: #25272c; color: #dddfe3; border: 1px solid #4b4f57; selection-background-color: #494137; padding: 4px; }
QDoubleSpinBox { padding: 3px 6px; }
QSlider::groove:horizontal { height: 3px; background: #3d4148; border-radius: 1px; }
QSlider::sub-page:horizontal { background: #ae916b; border-radius: 1px; }
QSlider::handle:horizontal { background: #e4ded4; border: 2px solid #27292e; width: 10px; height: 10px; margin: -5px 0; border-radius: 7px; }
QSlider::handle:horizontal:hover { background: #f3c994; }
QSlider::groove:horizontal:disabled, QSlider::sub-page:horizontal:disabled { background: #30343a; }
QSlider::handle:horizontal:disabled { background: #60646b; }
QScrollArea { background: transparent; border: none; }
QScrollArea > QWidget > QWidget { background: #1e2023; }
QScrollBar:vertical { background: transparent; width: 5px; margin: 2px 0; }
QScrollBar::handle:vertical { background: #4a4e56; border-radius: 2px; min-height: 28px; }
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }
QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical { background: none; }
QProgressBar { border: none; background: #292c31; border-radius: 2px; max-height: 3px; }
QProgressBar::chunk { background: #c9a674; }
QMenu { background: #25272c; border: 1px solid #454950; padding: 5px; }
QMenu::item { padding: 7px 18px; }
QMenu::item:selected { background: #423d35; }
QToolTip { color: #e4e4e6; background: #292c31; border: 1px solid #50545c; padding: 6px; }
QMessageBox { background: #202226; }
'''


def apply_theme(app):
    if app.property('cinematch_theme'):
        return
    app.setStyle('Fusion')
    palette = QPalette()
    for role, color in [(QPalette.ColorRole.Window, '#151618'),
                        (QPalette.ColorRole.WindowText, '#e2e3e5'),
                        (QPalette.ColorRole.Base, '#17191c'),
                        (QPalette.ColorRole.AlternateBase, '#25272c'),
                        (QPalette.ColorRole.Text, '#e2e3e5'),
                        (QPalette.ColorRole.Button, '#2b2e33'),
                        (QPalette.ColorRole.ButtonText, '#e2e3e5'),
                        (QPalette.ColorRole.Highlight, '#695740'),
                        (QPalette.ColorRole.HighlightedText, '#ffffff')]:
        palette.setColor(role, QColor(color))
    app.setPalette(palette)
    app.setStyleSheet(STYLE)
    app.setProperty('cinematch_theme', True)
