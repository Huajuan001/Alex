#!/bin/bash
# Persist resources BEFORE handing control to another macOS application.
set -eu
log_dir="$HOME/Library/Logs/CineMatchStudio"
mkdir -p "$log_dir"
exec >> "$log_dir/installer-launcher.log" 2>&1
printf '\nInstaller v0.4.0 entry: %s\n' "$(date)"
if resources="$(cd "$(dirname "$0")/../Resources" && pwd)"; then
    if [ -f "$resources/project/macos/stage-install.sh" ]; then
        # shellcheck source=macos/stage-install.sh
        if source "$resources/project/macos/stage-install.sh" && \
            payload="$(stage_install_project "$resources/project" "$HOME/Library/Application Support/CineMatchStudio/installers")"; then
            printf 'Persistent payload ready: %s\n' "$payload"
            if /usr/bin/open -a Terminal "$payload/开始安装.command"; then
                exit 0
            fi
        fi
    else
        printf 'Missing staging helper in installer resources\n' >&2
    fi
fi
/usr/bin/osascript - "$log_dir/installer-launcher.log" <<'APPLESCRIPT'
on run argv
    display dialog "准备安装文件失败。请重新完整解压安装包，或运行包内“显示安装进度.command”。日志：" & linefeed & (item 1 of argv) with title "CineMatch Studio" buttons {"好"} default button 1
end run
APPLESCRIPT
exit 1
