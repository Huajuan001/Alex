#!/bin/bash
# Copy the complete payload out of AppTranslocation BEFORE long-running work.
# This file is sourced; it does not change HOME or clean unrelated files.
stage_install_project() {
    local source="$1" root="$2" destination relative
    for relative in macos/install.py macos/install.sh macos/launch-app.sh \
        macos/install-console.command macos/plugin-requirements.lock \
        core/lut_generator.py core/cube.py ui/app.py resolve/inspect_local.py; do
        if [ ! -f "$source/$relative" ]; then
            printf '安装资源不完整：%s。请重新完整解压新版 ZIP。\n' "$relative" >&2
            return 1
        fi
    done
    mkdir -p "$root" || return 1
    destination="$(mktemp -d "$root/payload-0.4.0.XXXXXX")" || return 1
    if ! cp -R "$source" "$destination/project"; then
        printf '无法持久保存安装文件，暂存目录保留用于诊断：%s\n' "$destination" >&2
        return 1
    fi
    for relative in macos/install.py macos/install.sh macos/launch-app.sh \
        macos/install-console.command macos/plugin-requirements.lock \
        core/lut_generator.py core/cube.py ui/app.py resolve/inspect_local.py; do
        if [ ! -f "$destination/project/$relative" ]; then
            printf '持久安装资源缺失：%s，位置：%s\n' "$relative" "$destination" >&2
            return 1
        fi
    done
    cp "$destination/project/macos/install-console.command" "$destination/开始安装.command" || return 1
    chmod +x "$destination/开始安装.command" || return 1
    printf 'CineMatch persistent installer payload v0.4.0\n' > "$destination/.cinematch-staged" || return 1
    printf '%s\n' "$destination"
}
