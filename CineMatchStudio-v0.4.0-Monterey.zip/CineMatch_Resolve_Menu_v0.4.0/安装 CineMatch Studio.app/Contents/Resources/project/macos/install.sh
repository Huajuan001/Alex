#!/bin/bash
# No sudo, host Python, Homebrew, or Resolve Python configuration changes.
set -eu

show_message() {
    /usr/bin/osascript - "$1" <<'APPLESCRIPT'
on run argv
    display dialog (item 1 of argv) with title "CineMatch Studio 安装器" buttons {"好"} default button 1
end run
APPLESCRIPT
}

verify_archive() {
    local archive="$1" expected="$2"
    printf '%s  %s\n' "$expected" "$archive" | /usr/bin/shasum -a 256 -c -
}

supports_macos_version() {
    local version="$1" major
    major="${version%%.*}"
    case "$major" in
        ''|*[!0-9]*) return 1 ;;
    esac
    [ "$major" -ge 12 ]
}

install_stage() {
    cinematch_phase="$1"
    printf '\n[%s] %s\n' "$(date '+%H:%M:%S')" "$cinematch_phase"
}

finish_install() {
    local status="$1"
    if [ -n "$cinematch_stage_dir" ]; then
        rm -rf "$cinematch_stage_dir" || true
    fi
    if [ "$cinematch_have_lock" = 1 ]; then
        rm -f "$cinematch_lock_dir/pid" || true
        rmdir "$cinematch_lock_dir" 2>/dev/null || true
    fi
    if [ "$status" -ne 0 ]; then
        printf '\n安装失败或被中断，退出码 %s；阶段：%s\n日志：%s/install.log\n' \
            "$status" "$cinematch_phase" "$cinematch_log_dir" >&2
    fi
}

main() {
    if [ "$(uname -s)" != Darwin ]; then
        echo 'This installer requires macOS 12 or newer.' >&2
        return 1
    fi
    # Direct callers also receive a stable payload before any downloads.
    local project_dir base_dir persisted
    project_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
    base_dir="$HOME/Library/Application Support/CineMatchStudio"
    if [ ! -f "$project_dir/../.cinematch-staged" ]; then
        # shellcheck source=macos/stage-install.sh
        source "$project_dir/macos/stage-install.sh"
        persisted="$(stage_install_project "$project_dir" "$base_dir/installers")" || return 1
        exec /bin/bash "$persisted/project/macos/install.sh" "$@"
    fi
    # Start the log BEFORE the first dialog and any downloads.
    cinematch_log_dir="$HOME/Library/Logs/CineMatchStudio"
    mkdir -p "$cinematch_log_dir"
    cinematch_stage_dir=''
    cinematch_lock_dir=''
    cinematch_have_lock=0
    cinematch_phase='初始化'
    if [ "${1:-}" = --console ]; then
        exec > >(/usr/bin/tee -a "$cinematch_log_dir/install.log") 2>&1
    else
        exec >> "$cinematch_log_dir/install.log" 2>&1
    fi
    trap 'finish_install "$?"' EXIT
    printf '\nCineMatch v0.4.0 installation started: %s\n' "$(date)"
    printf '持久安装资源：%s\n' "$project_dir"
    install_stage '检查操作系统'
    local mac_version
    mac_version="$(/usr/bin/sw_vers -productVersion)"
    if ! supports_macos_version "$mac_version"; then
        show_message '此测试版需要 macOS 12 或更新版本。'
        return 1
    fi
    local log_dir runtime_dir archive arch filename expected url
    project_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
    base_dir="$HOME/Library/Application Support/CineMatchStudio"
    log_dir="$HOME/Library/Logs/CineMatchStudio"
    mkdir -p "$base_dir/runtimes" "$log_dir"
    install_stage '检查是否已有安装任务'
    cinematch_lock_dir="$base_dir/.install-lock"
    if ! mkdir "$cinematch_lock_dir" 2>/dev/null; then
        printf '安装锁存在。旧安装可能仍在下载；本次不会同时启动或删除旧安装锁。\n'
        if [ "${1:-}" != --console ]; then
            show_message '旧安装可能仍在运行。请使用“查看安装诊断.command”查看原任务；无需再次启动安装。'
        fi
        return 1
    fi
    cinematch_have_lock=1
    printf '%s\n' "$$" > "$cinematch_lock_dir/pid"
    if [ "${1:-}" != --console ]; then
        install_stage '等待用户确认，点击“好”后开始下载'
        show_message $'点击“好”后开始安装。首次需要联网下载约 180–250 MB。\n\n若要看到进度，请改用包内“显示安装进度.command”，不要重复启动多个安装任务。'
    fi
    arch="$(uname -m)"
    case "$arch" in
        arm64)
            arch=aarch64
            expected=5e656e09fc73c7ae10e4df66e6aa253f1f5980509b3be8a242e883d67a5fdf26
            ;;
        x86_64)
            expected=a870f5bb476ebe4483761ffdcd39b316dbef9f59f158706296d2c6f138057cae
            ;;
        *) show_message '不支持此 Mac 处理器架构。'; return 1 ;;
    esac
    filename="cpython-3.11.17+20261013-${arch}-apple-darwin-install_only_stripped.tar.gz"
    url="https://github.com/astral-sh/python-build-standalone/releases/download/20261013/$filename"
    runtime_dir="$base_dir/runtimes/cpython-3.11.17-20261013-$arch"
    if [ ! -x "$runtime_dir/bin/python3" ]; then
        cinematch_stage_dir="$(mktemp -d "$base_dir/runtimes/.download.XXXXXX")"
        archive="$cinematch_stage_dir/runtime.tar.gz"
        install_stage '下载 Python 运行环境（首次约 27 MB）'
        if ! /usr/bin/curl --fail --location --proto '=https' --tlsv1.2 --connect-timeout 20 --max-time 900 --retry 2 --output "$archive" "$url"; then
            show_message "运行环境下载失败。请检查网络后重试。日志：$log_dir/install.log"
            return 1
        fi
        install_stage '校验 Python 运行环境 SHA256'
        if ! verify_archive "$archive" "$expected"; then
            show_message "运行环境校验失败，已停止安装。日志：$log_dir/install.log"
            return 1
        fi
        install_stage '解压 Python 运行环境'
        if ! /usr/bin/tar -xzf "$archive" -C "$cinematch_stage_dir" || [ ! -x "$cinematch_stage_dir/python/bin/python3" ]; then
            show_message "运行环境解压失败。日志：$log_dir/install.log"
            return 1
        fi
        # Never replace an unknown directory or nest a new runtime inside it.
        if [ -e "$runtime_dir" ]; then
            show_message "存在不完整运行环境，未覆盖。请提供安装日志：$log_dir/install.log"
            return 1
        fi
        mv "$cinematch_stage_dir/python" "$runtime_dir"
        rm -rf "$cinematch_stage_dir"
        cinematch_stage_dir=''
    fi
    install_stage '创建独立 Python 环境并安装 NumPy、Pillow、Qt 等依赖（首次下载可能需要几分钟）'
    # -I isolates the installer from Resolve's Python environment variables.
    if ! "$runtime_dir/bin/python3" -I "$project_dir/macos/install.py" --project "$project_dir"; then
        show_message "安装未完成。请检查网络，并将以下日志发给开发者：$log_dir/install.log"
        return 1
    fi
    install_stage '安装完成'
    show_message $'安装完成。请重新打开 DaVinci Resolve，在「工作区 → 脚本 → CineMatch Studio」中启动。\n\n此版打开独立调色窗口；当前帧和 LUT 节点暂时手动导入。'
}

if [ "${BASH_SOURCE[0]}" = "$0" ]; then
    main "$@"
fi
