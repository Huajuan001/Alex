"""User-scoped macOS installation driver. Uses only the bootstrapped stdlib."""
import argparse
from datetime import datetime
import hashlib
import os
from pathlib import Path
import plistlib
import shutil
import subprocess
import sys
import tempfile
import uuid
import venv

VERSION = '0.4.0'
MINIMUM_MACOS = '12.0'
MARKER = 'CineMatch Studio menu launcher'
APP_MARKER = f'CineMatch Studio managed application v{VERSION}\n'
KNOWN_APP_MARKERS = (APP_MARKER, 'CineMatch Studio managed application v0.2.0\n',
                     'CineMatch Studio managed application v0.3.0\n',
                     'CineMatch Studio managed application v0.3.1\n',
                     'CineMatch Studio managed application v0.3.2\n')


def default_paths(home):
    home = Path(home)
    return (home/'Library/Application Support/CineMatchStudio',
            home/'Library/Application Support/Blackmagic Design/DaVinci Resolve/Fusion/Scripts/Utility')


def check_existing(app, menu):
    """Refuse to replace unknown user content even at our installation names."""
    if app.is_symlink() or menu.is_symlink():
        raise RuntimeError('Installation destination is a symlink; use a normal user-owned directory')
    if app.exists():
        marker = app/'Contents/Resources/cinematch-managed.txt'
        if not marker.is_file() or marker.read_text() not in KNOWN_APP_MARKERS:
            raise RuntimeError(f'An unrelated application already exists: {app}')
    if menu.exists() and MARKER not in menu.read_text(encoding='utf-8'):
        raise RuntimeError(f'An unrelated script already exists: {menu}')


def validate_project(project):
    required = ('macos/launch-app.sh', 'macos/plugin-requirements.lock',
                'core/lut_generator.py', 'core/cube.py', 'ui/app.py', 'resolve/inspect_local.py')
    missing = [name for name in required if not (project/name).is_file()]
    if missing:
        raise RuntimeError('Installer resource missing before setup: '+', '.join(missing)+
                           '. Re-extract the latest package; resources must be persisted outside AppTranslocation.')


def run(command):
    print('Running:', ' '.join(str(x) for x in command), flush=True)
    subprocess.run([str(x) for x in command], check=True)


def prepare_environment(base, lock):
    digest = hashlib.sha256(lock.read_bytes()).hexdigest()[:16]
    # Stable path: moving a venv would invalidate its absolute interpreter paths.
    env_root = base/'environments'/f'py311-{digest}'
    python = env_root/'bin/python'
    if not python.exists():
        venv.EnvBuilder(with_pip=True).create(env_root)
    run([python, '-I', '-m', 'pip', '--isolated', '--disable-pip-version-check',
         'install', '--index-url', 'https://pypi.org/simple', '--require-hashes',
         '--only-binary=:all:', '--no-input', '--progress-bar', 'on', '--timeout', '30', '--retries', '2', '-r', lock])
    run([python, '-I', '-c',
         'import numpy, tifffile; from PIL import Image, ImageCms; from PySide6.QtWidgets import QApplication; '
         'print("CineMatch dependencies verified")'])
    return python


def plist(name, executable, identifier):
    return {
        'CFBundleName': name, 'CFBundleDisplayName': name,
        'CFBundleExecutable': executable, 'CFBundleIdentifier': identifier,
        'CFBundlePackageType': 'APPL', 'CFBundleShortVersionString': VERSION,
        'CFBundleVersion': '6', 'LSMinimumSystemVersion': MINIMUM_MACOS,
        'NSHighResolutionCapable': True,
    }


def build_application(project, destination, python):
    contents = destination/'Contents'
    resources = contents/'Resources'
    executables = contents/'MacOS'
    resources.mkdir(parents=True)
    executables.mkdir()
    with (contents/'Info.plist').open('wb') as f:
        plistlib.dump(plist('CineMatch Studio', 'CineMatchStudio', 'studio.cinematch.desktop'), f)
    launcher = executables/'CineMatchStudio'
    shutil.copyfile(project/'macos/launch-app.sh', launcher)
    launcher.chmod(0o755)
    (resources/'python-path').write_text(str(python)+'\n')
    (resources/'cinematch-managed.txt').write_text(APP_MARKER)
    for package in ('core', 'ui', 'resolve'):
        shutil.copytree(project/package, resources/'project'/package,
                        ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))


def install_payload(project, base, scripts, python):
    validate_project(project)
    base, scripts = Path(base), Path(scripts)
    app, menu = base/'CineMatch Studio.app', scripts/'CineMatch Studio.lua'
    check_existing(app, menu)
    base.mkdir(parents=True, exist_ok=True)
    scripts.mkdir(parents=True, exist_ok=True)
    backup = base/'backups'/(datetime.now().strftime('%Y%m%d-%H%M%S')+'-'+uuid.uuid4().hex[:8])
    with tempfile.TemporaryDirectory(prefix='.app-stage-', dir=base) as temp:
        staged = Path(temp)/app.name
        build_application(project, staged, python)
        old_app = old_menu = None
        if app.exists() or menu.exists():
            backup.mkdir(parents=True)
        installed_new_app = False
        try:
            if app.exists():
                candidate = backup/app.name
                app.rename(candidate)
                old_app = candidate
            if menu.exists():
                candidate = backup/menu.name
                shutil.copy2(menu, candidate)
                old_menu = candidate
            staged.rename(app)
            installed_new_app = True
            temporary_menu = scripts/('.CineMatch-'+uuid.uuid4().hex+'.tmp')
            try:
                temporary_menu.write_bytes((project/'macos/CineMatchStudio.lua').read_bytes())
                os.replace(temporary_menu, menu)
            finally:
                temporary_menu.unlink(missing_ok=True)
        except Exception:
            if installed_new_app:
                shutil.rmtree(app)
            if old_app:
                old_app.rename(app)
            if old_menu:
                shutil.copy2(old_menu, menu)
            raise
    return app, menu


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--project', type=Path, required=True)
    args = p.parse_args(argv)
    if sys.platform != 'darwin':
        p.exit(2, 'This installer is for macOS only.\n')
    base, scripts = default_paths(Path.home())
    check_existing(base/'CineMatch Studio.app', scripts/'CineMatch Studio.lua')
    validate_project(args.project)
    python = prepare_environment(base, args.project/'macos/plugin-requirements.lock')
    app, menu = install_payload(args.project, base, scripts, python)
    print(f'Application installed: {app}\nResolve menu script installed: {menu}', flush=True)


if __name__ == '__main__':
    main()
