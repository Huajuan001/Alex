-- CineMatch Studio menu launcher v0.4.0 (managed by CineMatch installer).
-- Standard Lua only: no unverified Resolve/Fusion scripting API calls.
local function quote(value)
    return "'" .. value:gsub("'", "'\\''") .. "'"
end

local function succeeded(code)
    -- Lua 5.1 returns a number; newer Lua returns success boolean + status.
    return code == true or code == 0
end

local function notify(message)
    local script = 'on run argv\n display dialog (item 1 of argv) with title "CineMatch Studio" buttons {"好"} default button 1\nend run'
    os.execute('/usr/bin/osascript -e ' .. quote(script) .. ' ' .. quote(message))
end

local home = os.getenv('HOME')
if not home or home == '' then
    notify('无法找到用户目录，请通过安装器重新安装。')
    return
end
local app = home .. '/Library/Application Support/CineMatchStudio/CineMatch Studio.app'
local marker = io.open(app .. '/Contents/Resources/cinematch-managed.txt', 'r')
if not marker then
    notify('尚未安装 CineMatch Studio。请先运行下载包中的“安装 CineMatch Studio.app”。')
    return
end
marker:close()
local code = os.execute('/usr/bin/open -a ' .. quote(app))
if not succeeded(code) then
    notify('无法打开 CineMatch Studio。请重新运行安装器，并查看用户 Library/Logs/CineMatchStudio 中的日志。')
end
