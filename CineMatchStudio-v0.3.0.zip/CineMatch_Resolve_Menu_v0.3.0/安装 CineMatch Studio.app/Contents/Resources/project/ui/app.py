"""Run with python -m ui.app; image processing happens outside the GUI thread."""
import sys
import os
import json
from pathlib import Path
import numpy as np
from PySide6.QtCore import Qt, QObject, Signal, QRunnable, QThreadPool, QRect
from PySide6.QtGui import QImage, QPixmap, QPainter, QColor
from PySide6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QPushButton, QLabel, QFileDialog, QSlider, QComboBox, QScrollArea, QDoubleSpinBox, QFormLayout, QMessageBox)
from core.images import load_image
from core.matching import MatchSettings
from core.lut_generator import generate


def pixmap(rgb):
    data = np.ascontiguousarray(np.rint(rgb*255).astype('uint8'))
    h, w, _ = data.shape
    return QPixmap.fromImage(QImage(data.data, w, h, data.strides[0], QImage.Format.Format_RGB888).copy())


class Comparison(QWidget):
    def __init__(self):
        super().__init__()
        self.before = self.after = None
        self.position = 50
        self.setMinimumSize(400, 240)

    def paintEvent(self, event):
        p = QPainter(self)
        p.fillRect(self.rect(), QColor('#202020'))
        if self.before is None:
            p.setPen(Qt.GlobalColor.white)
            p.drawText(self.rect(), Qt.AlignmentFlag.AlignCenter, '选择源图和参考图，然后生成预览')
            return
        scaled = self.before.size().scaled(self.size(), Qt.AspectRatioMode.KeepAspectRatio)
        rect = QRect((self.width()-scaled.width())//2, (self.height()-scaled.height())//2,
                     scaled.width(), scaled.height())
        p.drawPixmap(rect, self.after)
        split = rect.left()+round(rect.width()*self.position/100)
        p.save()
        p.setClipRect(QRect(rect.left(), rect.top(), split-rect.left(), rect.height()))
        p.drawPixmap(rect, self.before)
        p.restore()
        p.setPen(Qt.GlobalColor.white)
        p.drawLine(split, rect.top(), split, rect.bottom())


class WorkerSignals(QObject):
    result = Signal(object)
    error = Signal(str)


class GenerateWorker(QRunnable):
    def __init__(self, source, reference, output, settings, mode="srgb", exposure=0):
        super().__init__()
        self.args = (source, reference, output, settings)
        self.mode, self.exposure = mode, exposure
        self.signals = WorkerSignals()

    def run(self):
        try:
            paths = generate(*self.args, mode=self.mode, exposure=self.exposure)
            before = load_image(paths['before'], max_size=1200)
            after = load_image(paths['preview'], max_size=1200)
            reference = load_image(self.args[1], max_size=320)
            self.signals.result.emit((paths, before, after, reference))
        except Exception as exc:
            self.signals.error.emit(f'{type(exc).__name__}: {exc}')


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('CineMatch Studio · sRGB / DWG Intermediate · 实验版')
        self.resize(1050, 820)
        self.source = self.reference = None
        self.output = str(Path(os.environ.get('CINEMATCH_OUTPUT_DIR', 'output')).expanduser().resolve())
        self.busy = False
        self.worker = None
        root = QWidget()
        self.setCentralWidget(root)
        layout = QVBoxLayout(root)
        self.warning = QLabel()
        self.warning.setWordWrap(True)
        layout.addWidget(self.warning)
        self.controls = QWidget()
        control_layout = QVBoxLayout(self.controls)
        for kind, title in [('source', '选择源图'), ('reference', '选择参考图')]:
            row = QHBoxLayout()
            button = QPushButton(title)
            label = QLabel('未选择')
            label.setWordWrap(True)
            setattr(self, kind+'_label', label)
            button.clicked.connect(lambda checked=False, k=kind: self.choose_image(k))
            row.addWidget(button)
            row.addWidget(label, 1)
            control_layout.addLayout(row)
        row = QHBoxLayout()
        button = QPushButton('选择输出目录')
        button.clicked.connect(self.choose_output)
        self.output_label = QLabel(self.output)
        self.output_label.setWordWrap(True)
        row.addWidget(button)
        row.addWidget(self.output_label, 1)
        control_layout.addLayout(row)
        form = QFormLayout()
        self.mode = QComboBox()
        self.mode.addItem('显示参考 sRGB → sRGB', 'srgb')
        self.mode.addItem('DWG / Intermediate → DWG / Intermediate（实验）', 'dwg')
        form.addRow('素材与 LUT 工作空间', self.mode)
        self.exposure = QDoubleSpinBox()
        self.exposure.setRange(-4, 4)
        self.exposure.setSingleStep(.1)
        form.addRow('手动曝光（档，仅 DWG）', self.exposure)
        self.strength = QSlider(Qt.Orientation.Horizontal)
        self.strength.setRange(0, 100)
        self.strength.setValue(70)
        self.strength_label = QLabel('匹配强度 70%')
        self.strength.valueChanged.connect(lambda v: self.strength_label.setText(f'匹配强度 {v}%（点击生成更新）'))
        form.addRow(self.strength_label, self.strength)
        self.options = {}
        for name, label, lo, hi, default in [('brightness', '编码亮度偏移', -.25, .25, 0),
                ('contrast', '对比度', .5, 1.5, 1), ('temperature', '冷 ← 色温 → 暖', -1, 1, 0),
                ('saturation', '饱和度', 0, 2, 1)]:
            spin = QDoubleSpinBox()
            spin.setRange(lo, hi)
            spin.setSingleStep(.05)
            spin.setValue(default)
            self.options[name] = spin
            form.addRow(label, spin)
        self.mode.currentIndexChanged.connect(self.update_mode)
        self.update_mode()
        control_layout.addLayout(form)
        self.run_button = QPushButton('生成预览并导出 33³ LUT')
        self.run_button.clicked.connect(self.start_generation)
        diagnostics = QPushButton('保存 Resolve 诊断信息')
        diagnostics.clicked.connect(self.save_diagnostics)
        control_layout.addWidget(QLabel('会覆盖所选输出目录下同名 CineMatch 文件；源图和参考图不应位于这些输出路径。'))
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setWidget(self.controls)
        scroll.setMinimumHeight(220)
        scroll.setMaximumHeight(410)
        layout.addWidget(scroll)
        actions = QHBoxLayout()
        actions.addWidget(self.run_button, 2)
        actions.addWidget(diagnostics, 1)
        layout.addLayout(actions)
        self.reference_view = QLabel('参考图预览')
        self.reference_view.setMaximumHeight(100)
        layout.addWidget(self.reference_view)
        self.comparison = Comparison()
        layout.addWidget(self.comparison, 1)
        layout.addWidget(QLabel('左：源图 / 右：LUT 输出。拖动分割线：'))
        wipe = QSlider(Qt.Orientation.Horizontal)
        wipe.setRange(0, 100)
        wipe.setValue(50)
        wipe.valueChanged.connect(self.set_wipe)
        layout.addWidget(wipe)
        self.status = QLabel('就绪。先选择图片；结果使用导出 LUT 的四面体插值。')
        self.status.setWordWrap(True)
        self.status.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        layout.addWidget(self.status)

    def update_mode(self):
        dwg = self.mode.currentData() == 'dwg'
        self.exposure.setEnabled(dwg)
        self.options['brightness'].setEnabled(not dwg)
        if dwg:
            self.options['brightness'].setValue(0)
            self.warning.setText('DWG 模式：源图必须为未经过显示变换的 DWG/Intermediate 全范围 RGB16/浮点 TIFF；参考图为 sRGB。\n'
                                 '调色 LUT 放在输出变换之前；相机 Log 请先转换到 DWG/Intermediate。预览采用 CineMatch 显示变换，非 Resolve DRT。')
        else:
            self.exposure.setValue(0)
            self.warning.setText('sRGB 模式：显示参考 sRGB 输入/输出；无 ICC 的图片按 sRGB 解释。\n'
                                 '此模式导出的 LUT 不可直接用于 Log / DWG。统计匹配原型，无语义肤色保护。')
        if hasattr(self, 'status'):
            self.status.setText('工作空间已改变，请确认源图编码并重新生成。当前预览仍为上次结果。')

    def choose_image(self, kind):
        path, _ = QFileDialog.getOpenFileName(self, '选择图片', '', ('DWG raw RGB16/float (*.tif *.tiff *.npy)' if kind == 'source' and self.mode.currentData() == 'dwg' else 'Images (*.png *.jpg *.jpeg *.tif *.tiff *.bmp *.webp)'))
        if path:
            setattr(self, kind, path)
            getattr(self, kind+'_label').setText(path)
            self.status.setText('输入已改变，请重新生成。当前预览仍为上次结果。')

    def choose_output(self):
        path = QFileDialog.getExistingDirectory(self, '选择输出目录', self.output)
        if path:
            self.output = path
            self.output_label.setText(path)

    def save_diagnostics(self):
        from resolve.inspect_local import inspect, DEFAULT_ROOTS
        path, _ = QFileDialog.getSaveFileName(self, '保存诊断信息',
                                             str(Path.home()/'Desktop/CineMatch_Resolve_Diagnostics.json'),
                                             'JSON (*.json)')
        if not path:
            return
        try:
            report = inspect(DEFAULT_ROOTS, include_excerpts=True)
            Path(path).write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
            self.status.setText('诊断已保存：'+path+'。包含本机开发文档路径及相关条目；未调用 Resolve API。')
        except (OSError, ValueError) as exc:
            QMessageBox.warning(self, '诊断失败', str(exc))

    def set_wipe(self, value):
        self.comparison.position = value
        self.comparison.update()

    def start_generation(self):
        if not self.source or not self.reference:
            QMessageBox.warning(self, '缺少图片', '请先选择源图和参考图。')
            return
        self.busy = True
        self.controls.setEnabled(False)
        self.run_button.setEnabled(False)
        self.status.setText('正在计算并导出，请稍候…')
        settings = MatchSettings(strength=self.strength.value()/100,
                                 **{name: spin.value() for name, spin in self.options.items()})
        self.worker = GenerateWorker(self.source, self.reference, self.output, settings, self.mode.currentData(), self.exposure.value())
        self.worker.signals.result.connect(self.show_result)
        self.worker.signals.error.connect(self.show_error)
        QThreadPool.globalInstance().start(self.worker)

    def show_result(self, result):
        paths, before, after, reference = result
        self.comparison.before, self.comparison.after = pixmap(before), pixmap(after)
        self.comparison.update()
        self.reference_view.setPixmap(pixmap(reference).scaledToHeight(100, Qt.TransformationMode.SmoothTransformation))
        self.status.setText('已导出：'+str(paths['lut'])+'\n对比图：'+str(paths['comparison']))
        self.busy = False
        self.controls.setEnabled(True)
        self.run_button.setEnabled(True)

    def show_error(self, error):
        self.busy = False
        self.controls.setEnabled(True)
        self.run_button.setEnabled(True)
        self.status.setText('生成失败：'+error+'。当前预览仍为上次成功结果。')
        QMessageBox.critical(self, '生成失败', error)

    def closeEvent(self, event):
        if self.busy:
            self.status.setText('正在保存输出，完成后即可关闭窗口。')
            event.ignore()
        else:
            event.accept()


def main():
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    return app.exec()


if __name__ == '__main__':
    raise SystemExit(main())
