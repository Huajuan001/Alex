"""R-fastest .cube serialization and tetrahedral evaluation."""
from pathlib import Path
import numpy as np
from .images import validate_rgb


def sample_transform(transform, size=33):
    if isinstance(size, bool) or not isinstance(size, int) or not 2 <= size <= 65:
        raise ValueError('LUT size must be an integer between 2 and 65')
    axis = np.linspace(0, 1, size)
    b, g, r = np.meshgrid(axis, axis, axis, indexing='ij')
    grid = np.stack([r, g, b], axis=-1)
    result = validate_rgb(transform(grid.reshape(-1, 3)), 'LUT output')
    if result.shape != (size**3, 3):
        raise ValueError('Transform must preserve RGB array shape')
    return result.reshape(size, size, size, 3)


def write_cube(table, path, *, title='CineMatch V1 - Display sRGB',
               input_space='display-referred sRGB encoded RGB [0,1]',
               output_space='display-referred sRGB encoded RGB [0,1]',
               usage='Not for Log or DWG/Intermediate'):
    for text in (title, input_space, output_space, usage):
        if any(c in text for c in ('\n', '\r', '"')):
            raise ValueError('Cube metadata cannot contain newlines or quotes')
    table = validate_rgb(table, 'LUT')
    if table.ndim != 4 or len(set(table.shape[:3])) != 1 or not 2 <= table.shape[0] <= 65:
        raise ValueError('Expected cubic LUT of shape (N, N, N, 3), N=2..65')
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('w', encoding='utf-8') as f:
        f.write(f'TITLE "{title}"\n')
        f.write(f'# Input: {input_space}\n# Output: {output_space}\n')
        f.write(f'# {usage}. Preview: tetrahedral interpolation.\n')
        f.write(f'LUT_3D_SIZE {table.shape[0]}\nDOMAIN_MIN 0.0 0.0 0.0\nDOMAIN_MAX 1.0 1.0 1.0\n')
        np.savetxt(f, table.reshape(-1, 3), fmt='%.7f')


def read_cube(path):
    size, rows = None, []
    for raw in Path(path).read_text(encoding='utf-8').splitlines():
        line = raw.split('#', 1)[0].strip()
        if not line:
            continue
        parts = line.split()
        key = parts[0]
        if key == 'TITLE':
            continue
        if key == 'LUT_3D_SIZE':
            if size is not None or len(parts) != 2:
                raise ValueError('Invalid or duplicate LUT_3D_SIZE')
            size = int(parts[1])
            if not 2 <= size <= 65:
                raise ValueError('Unsupported LUT size')
        elif key in ('DOMAIN_MIN', 'DOMAIN_MAX'):
            expected = [0., 0., 0.] if key == 'DOMAIN_MIN' else [1., 1., 1.]
            if [float(x) for x in parts[1:]] != expected:
                raise ValueError('Only domain [0,1] supported')
        else:
            if len(parts) != 3:
                raise ValueError('Invalid cube row')
            rows.append([float(x) for x in parts])
    if size is None or len(rows) != size**3:
        raise ValueError('LUT row count does not match size')
    return validate_rgb(rows, 'LUT').reshape(size, size, size, 3)


def apply_lut(rgb, table):
    """Evaluate all six tetrahedra; table axes are B, G, R."""
    rgb = validate_rgb(rgb)
    table = validate_rgb(table, 'LUT')
    if table.ndim != 4 or len(set(table.shape[:3])) != 1 or table.shape[0] < 2:
        raise ValueError('Invalid LUT shape')
    flat = rgb.reshape(-1, 3)
    out = np.empty_like(flat)
    size = table.shape[0]
    # Bound temporary memory for full-resolution images.
    for start in range(0, len(flat), 262144):
        x = flat[start:start+262144]*(size-1)
        base = np.minimum(np.floor(x).astype(int), size-2)
        frac = x-base
        order = np.argsort(-frac, axis=1, kind='stable')
        sorted_f = np.take_along_axis(frac, order, axis=1)
        steps = np.eye(3, dtype=int)[order]
        p1 = base+steps[:, 0]
        p2 = p1+steps[:, 1]
        p3 = base+1
        def lookup(p):
            return table[p[:, 2], p[:, 1], p[:, 0]]
        a, b, c = sorted_f.T
        out[start:start+len(x)] = (lookup(base)*(1-a[:, None]) + lookup(p1)*(a-b)[:, None]
                                 + lookup(p2)*(b-c)[:, None] + lookup(p3)*c[:, None])
    return np.clip(out.reshape(rgb.shape), 0, 1)


def export_cube(transform, path, size=33):
    write_cube(sample_transform(transform, size), path)
