"""Raw full-range DWG/Intermediate frames; NO ICC or display conversion."""
from pathlib import Path
import numpy as np
import tifffile
from .images import validate_rgb


def load_dwg(path, max_size=None):
    path = Path(path)
    if path.suffix.lower() == '.npy':
        data = np.load(path, allow_pickle=False)
        if data.dtype.kind != 'f' or data.dtype.itemsize < 4:
            raise ValueError('DWG NPY must contain float32/float64 encoded RGB')
    elif path.suffix.lower() in ('.tif', '.tiff'):
        try:
            with tifffile.TiffFile(path) as t:
                if len(t.pages) != 1:
                    raise ValueError('DWG TIFF must contain exactly one frame')
                page = t.pages[0]
                if page.photometric != 2 or page.samplesperpixel != 3 or page.planarconfig != 1:
                    raise ValueError('DWG TIFF must be interleaved RGB, without alpha')
                if 34675 in page.tags:
                    raise ValueError('DWG TIFF must not have a display ICC profile; export raw DWG/Intermediate')
                if 274 in page.tags and page.tags[274].value != 1:
                    raise ValueError('Orient the DWG TIFF before import (orientation must be 1)')
                data = page.asarray()
        except (tifffile.TiffFileError, ValueError) as exc:
            raise ValueError(f'Cannot load raw DWG TIFF: {exc}. Use uncompressed RGB16 or float32 TIFF.') from exc
        if data.dtype.kind == 'u' and data.dtype.itemsize == 2:
            data = data.astype(np.float64)/65535
        elif data.dtype.kind != 'f' or data.dtype.itemsize < 4:
            raise ValueError('DWG requires RGB16 or float32 TIFF, not an 8-bit screenshot')
    else:
        raise ValueError('DWG mode requires raw DWG/Intermediate RGB16/float TIFF or float NPY; PNG/JPEG is not accepted')
    data = validate_rgb(data, 'DWG/Intermediate full-range encoded data')
    if data.ndim != 3:
        raise ValueError('DWG frame must have shape (height, width, 3)')
    if max_size is not None:
        if not isinstance(max_size, int) or max_size < 1:
            raise ValueError('max_size must be a positive integer')
        # Subsample encoded values, without any 8-bit image conversion.
        step = max(1, int(np.ceil(max(data.shape[:2])/max_size)))
        data = data[::step, ::step]
    return data


def save_dwg(data, path):
    data = validate_rgb(data, 'DWG/Intermediate')
    if data.ndim != 3:
        raise ValueError('DWG frame must have shape (height, width, 3)')
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tifffile.imwrite(path, data.astype('float32'), photometric='rgb', metadata=None)
