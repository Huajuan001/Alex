"""CineMatch CLI: explicit display-sRGB or experimental DWG/Intermediate pipeline."""
import argparse
import json
from dataclasses import asdict
from pathlib import Path
import numpy as np
from .images import load_image, save_image
from .matching import build_transform, MatchSettings
from .cube import export_cube, sample_transform, write_cube, read_cube, apply_lut
from .color_spaces import dwg_to_display, VIEW_NAME

DWG_SPACE = 'DaVinci Wide Gamut / DaVinci Intermediate, full-range encoded RGB [0,1]'
SRGB_SPACE = 'display-referred sRGB encoded RGB [0,1]'


def generate(source_path, reference_path, output='output', settings=None, *, mode='srgb', exposure=0):
    settings = settings or MatchSettings()
    if mode not in ('srgb', 'dwg'):
        raise ValueError('mode must be srgb or dwg')
    if not np.isfinite(exposure) or not -4 <= exposure <= 4:
        raise ValueError('Exposure must be finite and between -4 and 4 stops')
    if mode == 'srgb' and exposure != 0:
        raise ValueError('Exposure in stops is available in DWG mode only')
    root = Path(output)
    lut_path = root/('luts/CineMatch_DWG_Intermediate_33.cube' if mode == 'dwg' else 'luts/CineMatch_Test_33.cube')
    preview_path, comparison_path = root/'previews/preview.png', root/'previews/comparison.png'
    before_path = root/'previews/before.png'
    manifest_path = root/'manifest.json'
    view_path, graded_path = root/'luts/CineMatch_View_DWG_to_sRGB_33.cube', root/'graded/graded_DWG_Intermediate.tiff'
    destinations = [lut_path, preview_path, comparison_path, before_path, manifest_path]
    if mode == 'dwg':
        destinations += [view_path, graded_path]
    inputs = {Path(source_path).resolve(), Path(reference_path).resolve()}
    if any(path.resolve() in inputs for path in destinations):
        raise ValueError('Output would overwrite an input image; choose a different output directory')
    reference = load_image(reference_path, max_size=1200)
    extra, paths = {}, {}
    if mode == 'dwg':
        from .dwg_images import load_dwg, save_dwg
        from .dwg_matching import build_dwg_transform
        source = load_dwg(source_path)
        # Raw values stay high precision throughout fitting and export.
        step = max(1, int(np.ceil(max(source.shape[:2])/1200)))
        source_sample = source[::step, ::step]
        view = sample_transform(dwg_to_display, 33)
        transform, parameters = build_dwg_transform(source_sample, reference, view, settings, exposure)
        write_cube(sample_transform(transform, 33), lut_path,
                   title='CineMatch Grade - DWG Intermediate', input_space=DWG_SPACE, output_space=DWG_SPACE,
                   usage='Grade BEFORE the output display transform. Not camera Log. Domain [0,1] only')
        write_cube(view, view_path, title='CineMatch Preview View - DWG to sRGB',
                   input_space=DWG_SPACE, output_space=SRGB_SPACE,
                   usage='Diagnostic display view ONLY. Replaces ODT for comparison; never stack with another ODT')
        view = read_cube(view_path)
        graded = apply_lut(source, read_cube(lut_path))
        save_dwg(graded, graded_path)
        before, matched = apply_lut(source, view), apply_lut(graded, view)
        extra = {
            'grade_input': DWG_SPACE, 'grade_output': DWG_SPACE,
            'reference_space': SRGB_SPACE,
            'lut_position': 'On DWG/Intermediate signal BEFORE Resolve output transform; camera Log must convert to DWG/Intermediate first',
            'source_interpretation': 'Raw encoded full-range DWG/Intermediate; no ICC conversion or video-range expansion',
            'preview_view': VIEW_NAME, 'preview_view_lut': str(view_path),
            'preview_warning': 'Not Resolve DRT. To compare pixels, use this exact view LUT and disable other display transforms',
            'fit_parameters': parameters,
            'domain_boundary_fraction': float(np.mean((graded <= 0) | (graded >= 1))),
            'domain_warning': '33-cube accepts only encoded [0,1]; outside values are unsupported. Negative scene channels and upper overflow are limited to that domain',
        }
        paths = {'view_lut': view_path, 'graded_dwg': graded_path}
    else:
        source = load_image(source_path)
        transform = build_transform(load_image(source_path, max_size=1200), reference, settings=settings)
        write_cube(sample_transform(transform, 33), lut_path)
        before, matched = source, apply_lut(source, read_cube(lut_path))
        extra = {'grade_input': SRGB_SPACE, 'grade_output': SRGB_SPACE,
                 'lut_position': 'Only matching display-sRGB input/output; never directly on Log or DWG/Intermediate',
                 'source_interpretation': 'Untagged assumed sRGB; tagged input converted using embedded ICC'}
    save_image(before, before_path)
    save_image(matched, preview_path)
    save_image(np.concatenate([before, matched], axis=1), comparison_path)
    metadata = {
        'source': str(Path(source_path)), 'reference': str(Path(reference_path)),
        'mode': mode, 'color_space': DWG_SPACE if mode == 'dwg' else SRGB_SPACE,
        'interpolation': 'tetrahedral', 'lut_size': 33,
        'comparison': 'left: source through preview view; right: serialized grade LUT through same view',
        'settings': asdict(settings), 'exposure_stops': exposure,
        'limitations': 'Global statistical prototype; no semantic skin protection or local matching; Resolve validation pending',
        **extra,
    }
    manifest_path.write_text(json.dumps(metadata, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    return {'lut': lut_path, 'preview': preview_path, 'before': before_path,
            'comparison': comparison_path, 'manifest': manifest_path, **paths}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', default='source.png')
    parser.add_argument('--reference', default='reference.png')
    parser.add_argument('--output', default='output')
    parser.add_argument('--mode', choices=('srgb', 'dwg'), default='srgb')
    parser.add_argument('--exposure', type=float, default=0, help='DWG manual exposure in stops (-4..4)')
    for name, default in [('strength', .7), ('brightness', 0.), ('contrast', 1.),
                          ('temperature', 0.), ('saturation', 1.)]:
        parser.add_argument('--'+name, type=float, default=default)
    args = parser.parse_args(argv)
    try:
        settings = MatchSettings(**{name: getattr(args, name) for name in asdict(MatchSettings())})
        paths = generate(args.source, args.reference, args.output, settings, mode=args.mode, exposure=args.exposure)
    except (ValueError, OSError) as exc:
        parser.exit(2, f'CineMatch: {exc}\n')
    for label, path in paths.items():
        print(f'{label}: {path}')


if __name__ == '__main__':
    main()
