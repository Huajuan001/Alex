"""Explicit 8-bit display sRGB input/output boundary."""
from io import BytesIO
from pathlib import Path
import numpy as np
import tifffile
from PIL import Image, ImageCms, ImageOps

SRGB = ImageCms.ImageCmsProfile(ImageCms.createProfile('sRGB'))

def validate_rgb(value, name='RGB'):
    rgb = np.asarray(value, dtype=np.float64)
    if rgb.ndim < 1 or rgb.shape[-1] != 3 or rgb.size == 0:
        raise ValueError(f'{name}: expected nonempty (..., 3) RGB array')
    if not np.isfinite(rgb).all() or np.any(rgb < 0) or np.any(rgb > 1):
        raise ValueError(f'{name}: values must be finite and within [0, 1]')
    return rgb


def load_image(path, max_size=None):
    """ICC-tagged images convert to sRGB; untagged RGB images assume sRGB.

    Reject HDR/16-bit, CMYK without a profile, and transparency: compositing
    against an arbitrary background would contaminate matching statistics.
    """
    if Path(path).suffix.lower() in ('.tif', '.tiff'):
        # Pillow cannot open some float-RGB TIFFs, and silently reduces some
        # RGB16 TIFFs to 8 bits. Inspect precision before handing it the file.
        with tifffile.TiffFile(path) as t:
            if t.pages[0].bitspersample > 8:
                raise ValueError('Only 8-bit display images supported here; use DWG mode for raw RGB16/float TIFF')
    with Image.open(path) as original:
        if original.format == 'TIFF':
            bits = original.tag_v2.get(258, (8,))
            bits = (bits,) if isinstance(bits, int) else bits
            if any(bit > 8 for bit in bits):
                raise ValueError('Only 8-bit display images supported here; use DWG mode for raw RGB16/float TIFF')
        if original.mode not in ('RGB', 'RGBA', 'L', 'LA', 'P', 'CMYK'):
            raise ValueError('Only 8-bit RGB/grayscale images are supported; convert HDR/16-bit first')
        im = ImageOps.exif_transpose(original)
        if im.mode in ('RGBA', 'LA', 'P') or 'transparency' in im.info:
            rgba = im.convert('RGBA')
            if rgba.getchannel('A').getextrema() != (255, 255):
                raise ValueError('Transparent image: flatten against the intended background first')
            im = rgba.convert('RGB')
        profile = original.info.get('icc_profile')
        if profile:
            try:
                src_profile = ImageCms.ImageCmsProfile(BytesIO(profile))
                # Grayscale and CMYK profiles need their original channel layout.
                im = ImageCms.profileToProfile(im, src_profile, SRGB, outputMode='RGB')
            except (OSError, ValueError, ImageCms.PyCMSError) as exc:
                raise ValueError('Cannot convert embedded ICC profile to sRGB') from exc
        elif im.mode == 'CMYK':
            raise ValueError('CMYK requires an embedded ICC profile')
        else:
            im = im.convert('RGB')
        if max_size is not None:
            if not isinstance(max_size, int) or max_size < 1:
                raise ValueError('max_size must be a positive integer')
            im.thumbnail((max_size, max_size), Image.Resampling.LANCZOS)
        return np.asarray(im, dtype=np.float64) / 255.0


def save_image(rgb, path):
    rgb = validate_rgb(rgb)
    if rgb.ndim != 3:
        raise ValueError('Image must have shape (height, width, 3)')
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    Image.fromarray(np.rint(rgb * 255).astype('uint8')).save(path, icc_profile=SRGB.tobytes())
