"""Published DWG/Intermediate encoding and a separately labelled preview view.

DWG primaries/DI constants: BMD Wide Gamut Intermediate information note;
corroborated by Colour Science (provenance in docs/DWG_WORKFLOW.md).
The Reinhard view here is OUR view, never Resolve's DRT or an inverse of it.
"""
import numpy as np
from .images import validate_rgb

DWG_TO_XYZ = np.array([[.70062239, .14877482, .10105872],
                       [.27411851, .87363190, -.14775041],
                       [-.09896291, -.13789533, 1.32591599]])
# sRGB D65 primaries-derived matrix, rather than the rounded 4-digit matrix.
SRGB_TO_XYZ = np.array([[.4123907992659595, .357584339383878, .1804807884018343],
                        [.2126390058715104, .715168678767756, .0721923153607337],
                        [.0193308187155918, .119194779794626, .9505321522496607]])
DWG_TO_SRGB = np.linalg.solve(SRGB_TO_XYZ, DWG_TO_XYZ)
SRGB_TO_DWG = np.linalg.inv(DWG_TO_SRGB)
DWG_LUMA = DWG_TO_XYZ[1]
SRGB_LUMA = SRGB_TO_XYZ[1]
VIEW_NAME = 'CineMatch luminance-Reinhard to sRGB v1 (not Resolve DRT)'


def finite(value):
    result = np.asarray(value, dtype=np.float64)
    if not np.isfinite(result).all():
        raise ValueError('Color values must be finite')
    return result


def intermediate_encode(linear):
    linear = finite(linear)
    result = np.empty_like(linear)
    mask = linear <= .00262409
    result[mask] = linear[mask]*10.44426855
    result[~mask] = (np.log2(linear[~mask]+.0075)+7)*.07329248
    return result


def intermediate_decode(encoded):
    encoded = finite(encoded)
    # A diagnostic/math function supports negative values; LUT domain is [0,1].
    if np.any(encoded > 2):
        raise ValueError('Intermediate code value exceeds supported numerical range')
    result = np.empty_like(encoded)
    mask = encoded <= .02740668
    result[mask] = encoded[mask]/10.44426855
    result[~mask] = np.exp2(encoded[~mask]/.07329248-7)-.0075
    return result


def srgb_decode(encoded):
    encoded = finite(encoded)
    result = np.empty_like(encoded)
    mask = encoded <= .04045
    result[mask] = encoded[mask]/12.92
    result[~mask] = ((encoded[~mask]+.055)/1.055)**2.4
    return result


def srgb_encode(linear):
    linear = finite(linear)
    result = np.empty_like(linear)
    mask = linear <= .0031308
    result[mask] = linear[mask]*12.92
    result[~mask] = 1.055*linear[~mask]**(1/2.4)-.055
    return result


def dwg_to_display(encoded):
    """Explicit diagnostic view: matrix, luminance Reinhard, gamut clip, sRGB.

    Tone/gamut clipping happens ONLY in this display view, not the grade LUT.
    No claim of matching Resolve DaVinci/ACES tone or gamut mapping.
    """
    linear_srgb = intermediate_decode(validate_rgb(encoded)) @ DWG_TO_SRGB.T
    luminance = np.maximum(linear_srgb @ SRGB_LUMA, 0)
    display_linear = linear_srgb/(1+luminance[..., None])
    return np.clip(srgb_encode(np.clip(display_linear, 0, 1)), 0, 1)
