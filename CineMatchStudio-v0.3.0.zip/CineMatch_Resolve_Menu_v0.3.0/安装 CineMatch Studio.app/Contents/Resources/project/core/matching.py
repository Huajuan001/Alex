"""Bounded global statistical matching in encoded display sRGB, not film transfer."""
from dataclasses import dataclass
import numpy as np
from .images import validate_rgb

LUMA = np.array([0.2126, 0.7152, 0.0722])

@dataclass(frozen=True)
class MatchSettings:
    strength: float = 0.7
    brightness: float = 0.0
    contrast: float = 1.0
    temperature: float = 0.0
    saturation: float = 1.0

    def __post_init__(self):
        for name, low, high in [('strength', 0, 1), ('brightness', -.25, .25),
                                ('contrast', .5, 1.5), ('temperature', -1, 1),
                                ('saturation', 0, 2)]:
            value = getattr(self, name)
            if not np.isfinite(value) or not low <= value <= high:
                raise ValueError(f'{name} must be finite and between {low} and {high}')


def build_transform(source, reference, strength=0.7, *, settings=None):
    settings = settings or MatchSettings(strength=strength)
    source = validate_rgb(source, 'source').reshape(-1, 3)
    reference = validate_rgb(reference, 'reference').reshape(-1, 3)
    sy, ry = source @ LUMA, reference @ LUMA
    slo, shi = np.percentile(sy, [2, 98])
    rlo, rhi = np.percentile(ry, [2, 98])
    # Constant/near-constant sources cannot support contrast estimation.
    scale = float(np.clip((rhi-rlo)/(shi-slo), .65, 1.5)) if shi-slo >= .05 else 1.0
    offset = float(np.clip(np.median(ry)-np.median(sy)*scale, -.15, .15))
    sm, rm = np.mean(source, axis=0), np.mean(reference, axis=0)
    # Estimate channel balance separately from encoded brightness/contrast.
    s_balance = (sm + .05) / (sm @ LUMA + .05)
    r_balance = (rm + .05) / (rm @ LUMA + .05)
    gains = np.clip(r_balance/s_balance, .8, 1.25)
    gains /= gains @ LUMA
    temp = np.array([1 + .12*settings.temperature, 1, 1 - .12*settings.temperature])

    def transform(rgb):
        rgb = validate_rgb(rgb)
        matched = (rgb * scale + offset) * gains
        matched = ((matched - .5)*settings.contrast + .5 + settings.brightness)*temp
        gray = (matched @ LUMA)[..., None]
        matched = gray + settings.saturation*(matched-gray)
        return np.clip(rgb + settings.strength*(matched-rgb), 0, 1)

    return transform
