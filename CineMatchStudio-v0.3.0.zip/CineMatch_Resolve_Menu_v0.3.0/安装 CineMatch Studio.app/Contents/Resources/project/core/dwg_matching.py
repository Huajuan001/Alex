"""Experimental scene-referred DWG grade, fitted against a labelled display view.

Reference display statistics guide bounded controls, not an inverse film DRT.
Grade decoding/encoding never passes through a clipped sRGB display image.
"""
import numpy as np
from .images import validate_rgb
from .matching import MatchSettings
from .color_spaces import (intermediate_encode, intermediate_decode, srgb_decode,
                           SRGB_TO_DWG, DWG_LUMA, VIEW_NAME)
from .cube import apply_lut


def contrast_curve(code, contrast):
    """Monotone, C1 piecewise power curve fixing 0, 18% gray, and 1."""
    code = np.clip(code, 0, 1)
    pivot = float(intermediate_encode(.18))
    result = np.empty_like(code)
    low = code <= pivot
    result[low] = pivot*(code[low]/pivot)**contrast
    result[~low] = 1-(1-pivot)*((1-code[~low])/(1-pivot))**contrast
    return result


def build_dwg_transform(source, reference, view_table, settings=None, exposure=0):
    settings = settings or MatchSettings()
    if not np.isfinite(exposure) or not -4 <= exposure <= 4:
        raise ValueError('DWG exposure must be finite and between -4 and 4 stops')
    if settings.brightness != 0:
        raise ValueError('Encoded sRGB brightness is unavailable in DWG mode; use exposure in stops')
    source = validate_rgb(source, 'DWG source')
    reference = validate_rgb(reference, 'sRGB reference')
    source_view = apply_lut(source, view_table)
    # Statistics are measured on the exact view used for the before preview.
    s_display = srgb_decode(source_view).reshape(-1, 3)
    r_display = srgb_decode(reference).reshape(-1, 3)
    s_dwg, r_dwg = s_display @ SRGB_TO_DWG.T, r_display @ SRGB_TO_DWG.T
    sy, ry = s_dwg @ DWG_LUMA, r_dwg @ DWG_LUMA
    auto_stops = float(np.clip(np.log2((np.median(ry)+.01)/(np.median(sy)+.01)), -2, 2))
    s_spread, r_spread = np.percentile(source_view, [98, 2]), np.percentile(reference, [98, 2])
    spread = s_spread[0]-s_spread[1]
    auto_contrast = float(np.clip((r_spread[0]-r_spread[1])/spread, .8, 1.2)) if spread >= .05 else 1.
    sm, rm = np.mean(s_dwg, axis=0), np.mean(r_dwg, axis=0)
    sb, rb = (sm+.05)/(sm @ DWG_LUMA+.05), (rm+.05)/(rm @ DWG_LUMA+.05)
    gains = np.clip(rb/sb, .85, 1.18)
    gains /= gains @ DWG_LUMA
    gains *= np.array([1+.12*settings.temperature, 1., 1-.12*settings.temperature])
    total_contrast = float(np.clip(auto_contrast*settings.contrast, .5, 1.5))
    upper = float(intermediate_decode(1.))

    def transform(encoded):
        encoded = validate_rgb(encoded, 'DWG LUT input')
        if settings.strength == 0:
            return encoded.copy()
        linear = intermediate_decode(encoded)*np.exp2(auto_stops+exposure)*gains
        y = linear @ DWG_LUMA
        positive = y > 1e-10
        ratio = np.ones_like(y)
        mapped = intermediate_decode(contrast_curve(intermediate_encode(y[positive]), total_contrast))
        ratio[positive] = mapped/y[positive]
        linear *= ratio[..., None]
        gray = (linear @ DWG_LUMA)[..., None]
        linear = gray+settings.saturation*(linear-gray)
        # LUT-domain limits only; 1.0 scene-linear is NOT a clipping threshold.
        result = intermediate_encode(np.clip(linear, 0, upper))
        return np.clip(encoded+settings.strength*(result-encoded), 0, 1)

    return transform, {'automatic_exposure_stops': auto_stops, 'manual_exposure_stops': exposure,
                       'automatic_contrast': auto_contrast, 'effective_contrast': total_contrast,
                       'channel_gains': gains.tolist(), 'fitting_view': VIEW_NAME,
                       'scene_linear_upper_domain': upper}
