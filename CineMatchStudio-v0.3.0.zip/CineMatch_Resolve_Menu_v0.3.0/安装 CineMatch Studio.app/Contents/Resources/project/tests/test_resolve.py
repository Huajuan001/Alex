import numpy as np
import pytest
from core.images import save_image
from resolve.compare_render import compare
from resolve.inspect_local import inspect


def test_render_comparison_detects_difference(tmp_path):
    a, b = tmp_path/'a.png', tmp_path/'b.png'
    save_image(np.full((4, 4, 3), .4), a)
    save_image(np.full((4, 4, 3), .5), b)
    assert compare(a, a)['passed']
    assert not compare(a, b)['passed']
    save_image(np.zeros((2, 2, 3)), b)
    with pytest.raises(ValueError, match='size mismatch'):
        compare(a, b)


def test_discovery_no_api_calls(tmp_path):
    (tmp_path/'README.txt').write_text('Local developer docs')
    result = inspect([tmp_path, tmp_path/'missing'])
    assert result['locations'][0]['documentation_or_modules'] == [str(tmp_path/'README.txt')]
    assert not result['locations'][1]['exists']
    assert result['api_verified'] is False


def test_documentation_excerpts_are_evidence_not_api_calls(tmp_path):
    (tmp_path/'README.txt').write_text('Example local docs\nExportCurrentFrameAsStill(path) example description\nend')
    result = inspect([tmp_path], include_excerpts=True)
    excerpts = result['locations'][0]['candidate_documentation_excerpts']
    assert len(excerpts) == 1
    assert excerpts[0]['line'] == 2
    assert 'ExportCurrentFrameAsStill' in excerpts[0]['text']
    assert result['api_verified'] is False
