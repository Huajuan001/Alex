import numpy as np
import pytest
from PIL import Image
from core.images import load_image, save_image
from core.matching import build_transform, MatchSettings
from core.cube import sample_transform, write_cube, read_cube, apply_lut
from core.lut_generator import generate, main

@pytest.fixture
def ramp():
    return np.random.default_rng(42).random((24, 32, 3))

@pytest.mark.parametrize('strength', [0, .3, .7, 1])
def test_strength_and_finite_bounds(ramp, strength):
    full = build_transform(ramp, ramp*.7+.1, strength=1)(ramp)
    actual = build_transform(ramp, ramp*.7+.1, strength=strength)(ramp)
    assert np.isfinite(actual).all()
    assert actual.min() >= 0 and actual.max() <= 1
    # Interior samples isolate strength blending from final clipping.
    interior = np.all((ramp>.2) & (ramp<.8), axis=-1)
    np.testing.assert_allclose(actual[interior], (ramp+strength*(full-ramp))[interior], atol=1e-12)

@pytest.mark.parametrize('value', [0., .4, 1.])
def test_constant_images_stable(value):
    src = np.full((5, 6, 3), value)
    out = build_transform(src, np.full_like(src, .5))(src)
    assert np.isfinite(out).all()
    np.testing.assert_allclose(out[..., 0], out[..., 1])

@pytest.mark.parametrize('bad', [np.array([]), np.zeros((2, 2)), np.full((2, 3), np.nan),
                                 np.full((2, 3), np.inf), np.full((2, 3), -1), np.full((2, 3), 1.1)])
def test_invalid_rgb_rejected(bad, ramp):
    with pytest.raises(ValueError):
        build_transform(bad, ramp)
    with pytest.raises(ValueError):
        build_transform(ramp, ramp)(bad)

@pytest.mark.parametrize('strength', [-.1, 1.1, float('nan'), float('inf')])
def test_invalid_strength(strength):
    with pytest.raises(ValueError):
        MatchSettings(strength=strength)

@pytest.mark.parametrize('size', [1, 3.5, True, 66])
def test_invalid_cube_size(size):
    with pytest.raises(ValueError):
        sample_transform(lambda x: x, size)


def test_33_cube_identity_all_rows_and_boundaries(tmp_path, ramp):
    table = sample_transform(lambda x: x)
    path = tmp_path/'identity.cube'
    write_cube(table, path)
    loaded = read_cube(path)
    assert loaded.shape == (33, 33, 33, 3)
    np.testing.assert_allclose(loaded, table, atol=5.1e-8)
    points = np.concatenate([ramp.reshape(-1, 3), [[0, 0, 0], [1, 1, 1], [1, 0, .5]]])
    np.testing.assert_allclose(apply_lut(points, loaded), points, atol=6e-8)


def test_channel_order_affine_exactness(ramp):
    def transform(x):
        return x[..., [2, 0, 1]]*.6+.1
    np.testing.assert_allclose(apply_lut(ramp, sample_transform(transform)), transform(ramp), atol=1e-12)


def test_all_tetrahedra_against_independent_scalar_reference():
    table = np.random.default_rng(4).random((2, 2, 2, 3))
    import itertools
    for order in itertools.permutations(range(3)):
        p = np.empty(3)
        p[list(order)] = [.8, .5, .2]
        vertices = [np.zeros(3, dtype=int)]
        for i in order:
            v = vertices[-1].copy()
            v[i] += 1
            vertices.append(v)
        expected = sum(w*table[v[2], v[1], v[0]] for w, v in zip([.2, .3, .3, .2], vertices))
        np.testing.assert_allclose(apply_lut(p, table), expected)


def test_roundtrip_preview_is_serialized_lut(tmp_path, ramp):
    src, ref = tmp_path/'src.png', tmp_path/'ref.png'
    save_image(ramp, src)
    save_image(ramp*.75+.1, ref)
    paths = generate(src, ref, tmp_path/'out')
    source = load_image(src)
    expected = np.rint(apply_lut(source, read_cube(paths['lut']))*255)/255
    np.testing.assert_array_equal(load_image(paths['preview']), expected)
    comparison = load_image(paths['comparison'])
    np.testing.assert_array_equal(comparison[:, :32], source)
    np.testing.assert_array_equal(comparison[:, 32:], expected)
    assert 'sRGB' in paths['manifest'].read_text()
    assert Image.open(paths['preview']).info['icc_profile']


def test_same_image_is_identity(ramp):
    np.testing.assert_allclose(build_transform(ramp, ramp)(ramp), ramp, atol=1e-12)


def test_neutral_tone_order():
    ramp = np.repeat(np.linspace(0, 1, 100)[:, None], 3, axis=1)
    result = build_transform(ramp, ramp*.8+.1)(ramp)
    assert np.all(np.diff(result, axis=0) >= 0)
    np.testing.assert_allclose(result[:, 0], result[:, 2])


def test_images_transparency_and_hdr_rejected(tmp_path):
    path = tmp_path/'alpha.png'
    Image.new('RGBA', (3, 3), (1, 2, 3, 0)).save(path)
    with pytest.raises(ValueError, match='Transparent'):
        load_image(path)
    path = tmp_path/'hdr.tiff'
    Image.fromarray(np.ones((3, 3), dtype=np.float32)).save(path)
    with pytest.raises(ValueError, match='8-bit'):
        load_image(path)


def test_exif_orientation(tmp_path):
    im = Image.new('RGB', (8, 4))
    exif = im.getexif()
    exif[274] = 6
    path = tmp_path/'rotated.jpg'
    im.save(path, exif=exif)
    assert load_image(path).shape == (8, 4, 3)


def test_corrupt_profile_rejected(tmp_path):
    path = tmp_path/'bad.png'
    Image.new('RGB', (4, 4)).save(path, icc_profile=b'not an ICC profile')
    with pytest.raises(ValueError, match='ICC'):
        load_image(path)


def test_truncated_cube_rejected(tmp_path):
    path = tmp_path/'bad.cube'
    path.write_text('LUT_3D_SIZE 33\n0 0 0\n')
    with pytest.raises(ValueError, match='row count'):
        read_cube(path)


def test_cli_missing_file(tmp_path, capsys):
    with pytest.raises(SystemExit) as exc:
        main(['--source', str(tmp_path/'missing.png')])
    assert exc.value.code == 2
    assert 'CineMatch:' in capsys.readouterr().err


def test_input_never_overwritten(tmp_path, ramp):
    src = tmp_path/'previews/preview.png'
    save_image(ramp, src)
    before = src.read_bytes()
    with pytest.raises(ValueError, match='overwrite'):
        generate(src, src, tmp_path)
    assert src.read_bytes() == before


@pytest.mark.parametrize('kwargs', [{'brightness': .26}, {'contrast': .4}, {'temperature': 2}, {'saturation': -1}])
def test_invalid_controls(kwargs):
    with pytest.raises(ValueError):
        MatchSettings(**kwargs)


def test_controls_have_effect_and_strength_zero_bypasses(ramp):
    settings = MatchSettings(strength=1, brightness=.04, contrast=1.1, temperature=.5, saturation=.8)
    assert not np.allclose(build_transform(ramp, ramp, settings=settings)(ramp), ramp)
    settings = MatchSettings(strength=0, brightness=.04, contrast=1.1, temperature=.5, saturation=.8)
    np.testing.assert_array_equal(build_transform(ramp, ramp, settings=settings)(ramp), ramp)
