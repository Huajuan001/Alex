import json
import numpy as np
import pytest
import tifffile
from PIL import Image
from core.color_spaces import (intermediate_encode, intermediate_decode, srgb_encode, srgb_decode,
                               DWG_TO_XYZ, SRGB_TO_DWG, DWG_TO_SRGB, dwg_to_display)
from core.dwg_images import load_dwg, save_dwg
from core.dwg_matching import build_dwg_transform, contrast_curve
from core.matching import MatchSettings
from core.cube import sample_transform, read_cube, apply_lut
from core.images import load_image, save_image
from core.lut_generator import generate, main

@pytest.fixture
def scene():
    gray = np.geomspace(.001, 64, 128).reshape(16, 8, 1)
    linear = np.repeat(gray, 3, axis=-1)
    return intermediate_encode(linear)

@pytest.fixture
def view():
    return sample_transform(dwg_to_display)


def test_published_middle_gray_and_black():
    assert intermediate_encode(.18) == pytest.approx(.336043272384855, abs=1e-12)
    assert intermediate_decode(.336043272384855) == pytest.approx(.18, abs=1e-12)
    assert intermediate_encode(0) == 0
    assert intermediate_decode(0) == 0
    assert intermediate_decode(1) == pytest.approx(100, abs=.001)


def test_independent_colour_science_conformance():
    colour = pytest.importorskip('colour')
    linear = np.concatenate([np.geomspace(1e-6, 100, 1024), [-.01, 0, .00262409, .18]])
    with np.errstate(invalid='ignore'):
        expected = colour.models.oetf_DaVinciIntermediate(linear)
    np.testing.assert_allclose(intermediate_encode(linear), expected, atol=1e-12)
    codes = np.linspace(-.02, 1, 1024)
    np.testing.assert_allclose(intermediate_decode(codes), colour.models.oetf_inverse_DaVinciIntermediate(codes), atol=1e-12)
    np.testing.assert_allclose(DWG_TO_XYZ, colour.models.RGB_COLOURSPACE_DAVINCI_WIDE_GAMUT.matrix_RGB_to_XYZ, atol=1e-8)


def test_transfer_roundtrips_and_matrix():
    linear = np.concatenate([np.linspace(-.01, .01, 100), np.geomspace(.01, 100, 200)])
    np.testing.assert_allclose(intermediate_decode(intermediate_encode(linear)), linear, atol=5e-10)
    linear = np.linspace(-.01, 1, 500)
    np.testing.assert_allclose(srgb_decode(srgb_encode(linear)), linear, atol=1e-12)
    np.testing.assert_allclose(DWG_TO_SRGB @ SRGB_TO_DWG, np.eye(3), atol=1e-12)
    np.testing.assert_allclose(np.ones(3) @ DWG_TO_SRGB.T, np.ones(3), atol=2e-8)


def test_matching_same_view_is_identity_and_preserves_hdr(scene, view):
    transform, params = build_dwg_transform(scene, apply_lut(scene, view), view, MatchSettings(strength=1))
    result = transform(scene)
    np.testing.assert_allclose(result, scene, atol=1e-9)
    assert params['automatic_exposure_stops'] == pytest.approx(0)
    assert intermediate_decode(result).max() > 63.99


def test_exposure_is_scene_linear_stops(scene, view):
    scene = np.minimum(scene, intermediate_encode(16.))
    transform, _ = build_dwg_transform(scene, apply_lut(scene, view), view, MatchSettings(strength=1), exposure=1)
    np.testing.assert_allclose(intermediate_decode(transform(scene)), 2*intermediate_decode(scene), atol=2e-8)


@pytest.mark.parametrize('strength', [0, .3, .7, 1])
def test_dwg_strength(scene, view, strength):
    reference = apply_lut(scene, view)*.85
    full, _ = build_dwg_transform(scene, reference, view, MatchSettings(strength=1))
    transform, _ = build_dwg_transform(scene, reference, view, MatchSettings(strength=strength))
    np.testing.assert_allclose(transform(scene), scene+strength*(full(scene)-scene), atol=1e-12)
    assert np.isfinite(transform(scene)).all()
    # Above display white remains scene HDR, not clipped to linear 1.0.
    assert intermediate_decode(transform(scene)).max() > 10


@pytest.mark.parametrize('contrast', [.5, 1, 1.5])
@pytest.mark.parametrize('exposure', [-4, 0, 4])
def test_gray_monotonic_under_controls(view, contrast, exposure):
    source = np.repeat(np.linspace(0, 1, 257)[:, None], 3, axis=1)
    transform, _ = build_dwg_transform(source, apply_lut(source, view), view,
                                      MatchSettings(strength=1, contrast=contrast), exposure)
    result = transform(source)
    assert np.all(np.diff(result, axis=0) >= -1e-10)
    assert result.min() >= 0 and result.max() <= 1


def test_curve_fixed_endpoints_and_pivot():
    values = np.array([0, float(intermediate_encode(.18)), 1])
    for c in [.5, 1, 1.5]:
        np.testing.assert_array_equal(contrast_curve(values, c), values)


def test_precision_tiff_and_npy_roundtrip(tmp_path, scene):
    tiff = tmp_path/'scene.tiff'
    save_dwg(scene, tiff)
    np.testing.assert_allclose(load_dwg(tiff), scene, atol=3e-8)
    npy = tmp_path/'scene.npy'
    np.save(npy, scene)
    np.testing.assert_array_equal(load_dwg(npy), scene)
    u16 = tmp_path/'scene16.tiff'
    tifffile.imwrite(u16, np.rint(scene*65535).astype('uint16'), photometric='rgb')
    np.testing.assert_allclose(load_dwg(u16), scene, atol=.5/65535)
    assert max(load_dwg(u16, max_size=4).shape[:2]) <= 4


@pytest.mark.parametrize('kind', ['png', 'uint8_tiff', 'uint8_npy', 'out_of_range', 'nan', 'alpha', 'multiple_frames', 'icc'])
def test_mislabelled_dwg_inputs_rejected(tmp_path, scene, kind):
    path = tmp_path/'input.tiff'
    if kind == 'png':
        path = tmp_path/'input.png'
        save_image(scene, path)
    elif kind == 'uint8_tiff':
        tifffile.imwrite(path, np.zeros((4, 4, 3), dtype='uint8'), photometric='rgb')
    elif kind == 'uint8_npy':
        path = tmp_path/'input.npy'
        np.save(path, np.zeros((4, 4, 3), dtype='uint8'))
    elif kind in ('out_of_range', 'nan'):
        path = tmp_path/'input.npy'
        data = scene.copy()
        data[0, 0, 0] = 1.1 if kind == 'out_of_range' else np.nan
        np.save(path, data)
    elif kind == 'alpha':
        tifffile.imwrite(path, np.zeros((4, 4, 4), dtype='uint16'), photometric='rgb')
    elif kind == 'multiple_frames':
        with tifffile.TiffWriter(path) as t:
            for _ in range(2):
                t.write(scene.astype('float32'), photometric='rgb')
    else:
        tifffile.imwrite(path, scene.astype('float32'), photometric='rgb', iccprofile=b'ICC profile')
    with pytest.raises(ValueError):
        load_dwg(path)


def test_generated_dwg_preview_uses_both_serialized_luts(tmp_path, scene, view):
    source, reference = tmp_path/'scene.tiff', tmp_path/'reference.png'
    save_dwg(scene, source)
    save_image(apply_lut(scene, view)*.9, reference)
    paths = generate(source, reference, tmp_path/'result', mode='dwg')
    raw = load_dwg(source)
    grade, display = read_cube(paths['lut']), read_cube(paths['view_lut'])
    graded = apply_lut(raw, grade)
    expected = np.rint(apply_lut(graded, display)*255)/255
    np.testing.assert_array_equal(load_image(paths['preview']), expected)
    np.testing.assert_array_equal(load_image(paths['before']), np.rint(apply_lut(raw, display)*255)/255)
    np.testing.assert_allclose(load_dwg(paths['graded_dwg']), graded, atol=3e-8)
    metadata = json.loads(paths['manifest'].read_text())
    assert metadata['mode'] == 'dwg'
    assert metadata['grade_input'] == metadata['grade_output']
    assert 'BEFORE' in metadata['lut_position']
    assert 'Not Resolve DRT' in metadata['preview_warning']
    header = paths['lut'].read_text().splitlines()[:6]
    assert any('DWG' in line for line in header)
    assert not any('Not for Log or DWG' in line for line in header)
    assert grade.shape == (33, 33, 33, 3)


def test_zero_strength_dwg_cube_identity(tmp_path, scene, view):
    source, reference = tmp_path/'scene.npy', tmp_path/'reference.png'
    np.save(source, scene)
    save_image(apply_lut(scene, view), reference)
    paths = generate(source, reference, tmp_path/'zero', MatchSettings(strength=0), mode='dwg', exposure=4)
    np.testing.assert_allclose(apply_lut(scene, read_cube(paths['lut'])), scene, atol=6e-8)


def test_dwg_cli_and_invalid_options(tmp_path, scene, view):
    source, reference = tmp_path/'scene.npy', tmp_path/'reference.png'
    np.save(source, scene)
    save_image(apply_lut(scene, view), reference)
    main(['--source', str(source), '--reference', str(reference), '--mode', 'dwg', '--output', str(tmp_path/'cli')])
    assert (tmp_path/'cli/luts/CineMatch_DWG_Intermediate_33.cube').is_file()
    for kwargs in [dict(mode='unknown'), dict(mode='srgb', exposure=1), dict(mode='dwg', exposure=float('nan')),
                   dict(mode='dwg', settings=MatchSettings(brightness=.1))]:
        with pytest.raises(ValueError):
            generate(source, reference, tmp_path/'invalid', **kwargs)


def test_dwg_input_not_overwritten_by_graded_export(tmp_path, scene, view):
    source = tmp_path/'graded/graded_DWG_Intermediate.tiff'
    reference = tmp_path/'reference.png'
    save_dwg(scene, source)
    save_image(apply_lut(scene, view), reference)
    original = source.read_bytes()
    with pytest.raises(ValueError, match='overwrite'):
        generate(source, reference, tmp_path, mode='dwg')
    assert source.read_bytes() == original


def test_compare_raw_dwg_is_not_8bit_display_conversion(tmp_path, scene):
    from resolve.compare_render import compare
    a, b = tmp_path/'a.tiff', tmp_path/'b.tiff'
    save_dwg(scene, a)
    save_dwg(np.clip(scene+.0002, 0, 1), b)
    assert compare(a, a, 1e-6, space='dwg')['passed']
    assert not compare(a, b, 1e-6, space='dwg')['passed']
    with pytest.raises(ValueError, match='8-bit'):
        load_image(a)


def test_rgb16_is_not_silently_quantized_by_display_loader(tmp_path):
    path = tmp_path/'rgb16.tiff'
    tifffile.imwrite(path, np.full((4, 4, 3), 32769, dtype='uint16'), photometric='rgb')
    with pytest.raises(ValueError, match='8-bit'):
        load_image(path)
