import numpy as np
from core.lut_generator import build_transform, export_cube


def test_zero_strength_identity():
    src = np.linspace(0, 1, 300, dtype=np.float32).reshape(10, 10, 3)
    transform = build_transform(src, src * 0.7, strength=0)
    np.testing.assert_allclose(transform(src), src, atol=1e-6)


def test_lut_line_count_and_order(tmp_path):
    path = tmp_path / "identity.cube"
    export_cube(lambda x: x, path, size=3)
    lines = path.read_text().splitlines()
    data = [line for line in lines if line and line[0].isdigit()]
    assert len(data) == 27
    assert data[0] == "0.0000000 0.0000000 0.0000000"
    assert data[1] == "0.5000000 0.0000000 0.0000000"
    assert data[3] == "0.0000000 0.5000000 0.0000000"
    assert data[9] == "0.0000000 0.0000000 0.5000000"
