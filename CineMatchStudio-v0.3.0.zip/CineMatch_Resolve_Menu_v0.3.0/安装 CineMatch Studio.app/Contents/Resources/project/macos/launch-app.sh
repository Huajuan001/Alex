#!/bin/bash
set -eu
contents_dir="$(cd "$(dirname "$0")/.." && pwd)"
IFS= read -r python_path < "$contents_dir/Resources/python-path"
project_dir="$contents_dir/Resources/project"
log_dir="$HOME/Library/Logs/CineMatchStudio"
mkdir -p "$log_dir"
export CINEMATCH_OUTPUT_DIR="$HOME/Pictures/CineMatch Studio"
# Qt must load this environment's own plugins, not those inherited from Resolve.
unset PYTHONHOME PYTHONPATH QT_PLUGIN_PATH QT_QPA_PLATFORM_PLUGIN_PATH QT_QPA_PLATFORM QT_QPA_FONTDIR QML2_IMPORT_PATH
cd "$project_dir"
if "$python_path" -I -c 'import sys; sys.path.insert(0, sys.argv[1]); from ui.app import main; raise SystemExit(main())' "$project_dir" >> "$log_dir/runtime.log" 2>&1; then
    exit 0
else
    /usr/bin/osascript - "$log_dir/runtime.log" <<'APPLESCRIPT'
on run argv
    display dialog "CineMatch 启动或运行失败。诊断日志：" & linefeed & (item 1 of argv) with title "CineMatch Studio" buttons {"好"} default button 1
end run
APPLESCRIPT
    exit 1
fi
