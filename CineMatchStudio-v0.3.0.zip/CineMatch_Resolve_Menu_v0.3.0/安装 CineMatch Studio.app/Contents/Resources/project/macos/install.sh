#!/bin/bash
# No sudo, host Python, Homebrew, or Resolve Python configuration changes.
set -eu

show_message() {
    /usr/bin/osascript - "$1" <<'APPLESCRIPT'
on run argv
    display dialog (item 1 of argv) with title "CineMatch Studio 安装器" buttons {"好"} default button 1
end run
APPLESCRIPT
}

verify_archive() {
    local archive="$1" expected="$2"
    printf '%s  %s\n' "$expected" "$archive" | /usr/bin/shasum -a 256 -c -
}

main() {
    if [ "$(uname -s)" != Darwin ]; then
        echo 'This installer requires macOS 13 or newer.' >&2
        return 1
    fi
    local mac_version major
    mac_version="$(/usr/bin/sw_vers -productVersion)"
    major="${mac_version%%.*}"
    if [ "$major" -lt 13 ]; then
        show_message '此测试版需要 macOS 13 或更新版本。'
        return 1
    fi
    local project_dir base_dir log_dir runtime_dir archive arch filename expected url
    project_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
    base_dir="$HOME/Library/Application Support/CineMatchStudio"
    log_dir="$HOME/Library/Logs/CineMatchStudio"
    mkdir -p "$base_dir/runtimes" "$log_dir"
    cinematch_lock_dir="$base_dir/.install-lock"
    if ! mkdir "$cinematch_lock_dir" 2>/dev/null; then
        show_message '另一个安装器可能正在运行。请等待其完成。若之前意外退出，请将安装日志发给开发者。'
        return 1
    fi
    cinematch_stage_dir=''
    # Only remove this run's owned temporary staging directory and lock.
    trap 'if [ -n "$cinematch_stage_dir" ]; then rm -rf "$cinematch_stage_dir"; fi; rmdir "$cinematch_lock_dir" 2>/dev/null || true' EXIT
    show_message $'将安装 CineMatch 的独立运行环境和达芬奇脚本菜单入口。首次安装需要联网下载约 200–300 MB，可能需要几分钟。无需安装 Python 或输入管理员密码。\n\n完成后会再次提示。'
    exec >> "$log_dir/install.log" 2>&1
    printf '\nCineMatch installation started: %s\n' "$(date)"
    arch="$(uname -m)"
    case "$arch" in
        arm64)
            arch=aarch64
            expected=5e656e09fc73c7ae10e4df66e6aa253f1f5980509b3be8a242e883d67a5fdf26
            ;;
        x86_64)
            expected=a870f5bb476ebe4483761ffdcd39b316dbef9f59f158706296d2c6f138057cae
            ;;
        *) show_message '不支持此 Mac 处理器架构。'; return 1 ;;
    esac
    filename="cpython-3.11.17+20261013-${arch}-apple-darwin-install_only_stripped.tar.gz"
    url="https://github.com/astral-sh/python-build-standalone/releases/download/20261013/$filename"
    runtime_dir="$base_dir/runtimes/cpython-3.11.17-20261013-$arch"
    if [ ! -x "$runtime_dir/bin/python3" ]; then
        cinematch_stage_dir="$(mktemp -d "$base_dir/runtimes/.download.XXXXXX")"
        archive="$cinematch_stage_dir/runtime.tar.gz"
        if ! /usr/bin/curl --fail --location --proto '=https' --tlsv1.2 --connect-timeout 20 --max-time 900 --retry 2 --output "$archive" "$url"; then
            show_message "运行环境下载失败。请检查网络后重试。日志：$log_dir/install.log"
            return 1
        fi
        if ! verify_archive "$archive" "$expected"; then
            show_message "运行环境校验失败，已停止安装。日志：$log_dir/install.log"
            return 1
        fi
        if ! /usr/bin/tar -xzf "$archive" -C "$cinematch_stage_dir" || [ ! -x "$cinematch_stage_dir/python/bin/python3" ]; then
            show_message "运行环境解压失败。日志：$log_dir/install.log"
            return 1
        fi
        # Never replace an unknown directory or nest a new runtime inside it.
        if [ -e "$runtime_dir" ]; then
            show_message "存在不完整运行环境，未覆盖。请提供安装日志：$log_dir/install.log"
            return 1
        fi
        mv "$cinematch_stage_dir/python" "$runtime_dir"
        rm -rf "$cinematch_stage_dir"
        cinematch_stage_dir=''
    fi
    # -I isolates the installer from Resolve's Python environment variables.
    if ! "$runtime_dir/bin/python3" -I "$project_dir/macos/install.py" --project "$project_dir"; then
        show_message "安装未完成。请检查网络，并将以下日志发给开发者：$log_dir/install.log"
        return 1
    fi
    show_message $'安装完成。请重新打开 DaVinci Resolve，在「工作区 → 脚本 → CineMatch Studio」中启动。\n\n此版打开独立调色窗口；当前帧和 LUT 节点暂时手动导入。'
}

if [ "${BASH_SOURCE[0]}" = "$0" ]; then
    main "$@"
fi
