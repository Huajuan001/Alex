"""User-scoped macOS installer and standard-Lua Resolve menu launcher."""
