"""Local documentation discovery and manual Resolve verification helpers."""
