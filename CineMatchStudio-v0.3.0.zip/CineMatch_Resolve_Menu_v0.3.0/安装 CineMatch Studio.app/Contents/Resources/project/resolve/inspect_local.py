"""Locate installed Developer Documentation before designing API probes.

Does not call or assume any Resolve scripting methods, change projects, or
configure system files. Run on the target Mac and share the relevant docs.
"""
import argparse
import json
from pathlib import Path
import platform


DEFAULT_ROOTS = [
    '/Library/Application Support/Blackmagic Design/DaVinci Resolve/Developer',
    '/Applications/DaVinci Resolve/DaVinci Resolve.app/Contents/Resources/Developer',
]
SEARCH_TERMS = ('GetVersionString', 'ExportCurrentFrameAsStill', 'RefreshLUTList',
                'SetLUT', 'GetCurrentVideoItem', 'GetNodeGraph', 'UIManager', 'UIDispatcher')


def inspect(roots, *, include_excerpts=False):
    records = []
    for root in roots:
        root = Path(root).expanduser()
        files = []
        if root.is_dir():
            for path in root.rglob('*'):
                if path.is_file() and (path.suffix.lower() in ('.txt', '.pdf', '.md') or
                                       path.name in ('DaVinciResolveScript.py', 'fusionscript.so')):
                    files.append(str(path))
        record = {'root': str(root), 'exists': root.exists(), 'documentation_or_modules': sorted(files)}
        if include_excerpts:
            excerpts = []
            for name in sorted(files):
                path = Path(name)
                if path.suffix.lower() not in ('.txt', '.md') or path.stat().st_size > 2_000_000:
                    continue
                try:
                    lines = path.read_text(encoding='utf-8', errors='replace').splitlines()
                except OSError as exc:
                    excerpts.append({'file': name, 'read_error': str(exc)})
                    continue
                hits = [i for i, line in enumerate(lines) if any(term in line for term in SEARCH_TERMS)]
                for i in hits[:100]:
                    excerpts.append({'file': name, 'line': i+1, 'text': '\n'.join(lines[max(0,i-1):i+4])})
            record['candidate_documentation_excerpts'] = excerpts
        records.append(record)
    return {'platform': platform.platform(), 'locations': records,
            'api_verified': False,
            'next_step': 'Read the installed Resolve 21 Studio documentation before writing API calls. No methods were called.'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', action='append', help='Additional installed Developer Documentation root')
    args = parser.parse_args()
    roots = args.root or DEFAULT_ROOTS
    print(json.dumps(inspect(roots), ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
