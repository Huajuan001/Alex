"""Compare an exported Resolve still to the generated LUT preview, without alignment."""
import argparse
import json
import numpy as np
from core.images import load_image


def compare(expected_path, actual_path, tolerance=2/255, *, space="srgb"):
    if not np.isfinite(tolerance) or tolerance < 0 or tolerance > 1:
        raise ValueError('Tolerance must be in [0,1]')
    if space == 'dwg':
        from core.dwg_images import load_dwg
        loader = load_dwg
    elif space == 'srgb':
        loader = load_image
    else:
        raise ValueError('Comparison space must be srgb or dwg')
    expected, actual = loader(expected_path), loader(actual_path)
    if expected.shape != actual.shape:
        raise ValueError(f'Image size mismatch: {expected.shape} vs {actual.shape}; export native resolution without resizing')
    diff = np.abs(expected-actual)
    maximum = float(diff.max())
    return {'mae': float(diff.mean()), 'rmse': float(np.sqrt(np.mean(diff**2))),
            'max_error': maximum, 'p99_error': float(np.percentile(diff, 99)),
            'tolerance': tolerance, 'passed': maximum <= tolerance,
            'space': space, 'note': 'Only meaningful with identical sRGB encoding, node placement, interpolation, no other grades or resizing.'}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('expected')
    p.add_argument('actual')
    p.add_argument('--space', choices=('srgb', 'dwg'), default='srgb')
    p.add_argument('--tolerance', type=float, default=2/255)
    args = p.parse_args()
    try:
        report = compare(args.expected, args.actual, args.tolerance, space=args.space)
    except (ValueError, OSError) as exc:
        p.exit(2, f'CineMatch comparison: {exc}\n')
    print(json.dumps(report, indent=2))
    return 0 if report['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
