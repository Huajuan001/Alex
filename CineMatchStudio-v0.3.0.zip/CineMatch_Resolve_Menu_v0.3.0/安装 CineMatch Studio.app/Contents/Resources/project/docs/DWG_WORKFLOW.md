# DWG / Intermediate 工作模式（v0.3.0 实验版）

## 在界面里使用

1. 打开新版安装器，完成后重开 Resolve。已有 v0.2.0 可直接升级，旧应用和菜单脚本会备份。
2. 从脚本菜单启动 CineMatch，在“素材与 LUT 工作空间”选择 **DWG / Intermediate → DWG / Intermediate**。
3. 选择真正编码为 DWG / Intermediate 的 **全范围 RGB16 或 float32/64 TIFF**，参考图选择普通 sRGB 图片。可先用下载包内“DWG 示例”的两张图试跑。
4. 调整强度、曝光（档）、对比度、冷暖和饱和度，生成结果。
5. 在 Resolve 的 DWG / Intermediate 节点上加载 `CineMatch_DWG_Intermediate_33.cube`，放在输出显示变换之前。

**文件扩展名不能证明色彩空间。** 工具无法从 TIFF 自动识别是否真为 DWG。不要将普通 TIFF、套过显示 LUT 的截图、相机原生 Log TIFF 改名后当作 DWG 输入。源帧必须与准备加载调色 LUT 的节点输入保持同一空间和相同上游调色。

当前不自动提取 Resolve 节点数据。根据本机 Resolve 21 文档，在独立测试项目/时间线上导出没有输出显示变换的 DWG/Intermediate 静帧，明确使用全范围与 16 位 TIFF。若静帧导出始终经过项目输出变换，须先确认并解决该路径，不能把得到的显示图当作原始 DWG。无法确认时先用附带校准图，保存并提供本机开发文档诊断报告以继续开发读取功能。

## 两种正确的节点位置

| 工程设置 | 节点/转换顺序 |
|---|---|
| 色彩管理工程，时间线工作空间确认为 DWG / Intermediate | 相机输入解释 → 时间线 DWG / Intermediate → **CineMatch DWG 调色 LUT** → 工程输出显示变换 |
| 手动管理的 DaVinci YRGB 测试工程 | 相机原生空间/Log → 正确的输入 CST 到 DWG / Intermediate → **CineMatch DWG 调色 LUT** → 输出 CST/显示变换 |

相机原生 S-Log3、LogC、C-Log 等并不是 DWG / Intermediate。请按准确的相机色域及曲线选择输入转换，避免在已经由工程色彩管理转换过的素材上重复 CST。当前版本没有原生相机 Log 预设，也不自动检测。

## 生成的两类 LUT

- **`CineMatch_DWG_Intermediate_33.cube`**：调色 LUT，输入/输出均为 DWG / Intermediate。用于正式 DWG 节点，保留后续输出变换。它不是 sRGB 显示 LUT。
- **`CineMatch_View_DWG_to_sRGB_33.cube`**：诊断用显示 LUT，输入 DWG / Intermediate、输出 sRGB。用于复现 CineMatch 预览，不能继续当作 DWG 输出，也不能与工程的另一套输出变换叠加。

还会生成：sRGB 的 `before.png`、`preview.png`、`comparison.png`，以及浮点的 `graded/graded_DWG_Intermediate.tiff` 和记录参数/空间/节点位置的 `manifest.json`。

## 为什么预览可能与 Resolve 不同

本工具的预览视图是 **CineMatch luminance-Reinhard to sRGB v1**：

1. Intermediate 解码为场景线性 DWG。
2. D65 矩阵转换到线性 sRGB。
3. 用 `RGB / (1 + max(Y, 0))` 做亮度 Reinhard 映射。
4. 仅在显示阶段裁剪显示色域，再应用 sRGB 编码。

这不是 Resolve DaVinci DRT、ACES 或其反函数。调色 LUT 本身不经过这条显示裁剪路径。正常工程使用 Resolve 输出变换时，预览可能出现合理的高光/饱和度差异；不能宣传两者已经一致。

逐像素验收时，在独立且无自动色彩管理的测试工程中，将同一 DWG 源图依次通过 **DWG 调色 LUT → 随附 View LUT → 无其他显示变换**，选择四面体 LUT 插值，按源尺寸导出确实为 sRGB 的 8-bit PNG，再与 Python `preview.png` 比较。也可仅应用调色 LUT，按原编码导出高精度 DWG TIFF，与 `graded_DWG_Intermediate.tiff` 比较。两条路径都需要本机验证，不能用 UI 截屏替代导出图。

开发者检测命令（普通用户不必在终端运行，可将导出图和诊断报告反馈）：

```bash
# 显示像素比较：初始最大误差阈值 2/255
python -m resolve.compare_render output/shot/previews/preview.png resolve_srgb.png
# 调色后的 DWG 编码比较：初始最大误差阈值约两个 16-bit 码值
python -m resolve.compare_render output/shot/graded/graded_DWG_Intermediate.tiff resolve_dwg.tiff \
  --space dwg --tolerance 0.0000306
```

阈值是验收标准，不是已测得的 Resolve 21 精度。自动测试验证的是 Python 内部及独立数学实现，尚无 Resolve 21 的实测报告。

## 算法与范围

参考图仍是显示 sRGB，并不假设它存在可恢复的电影场景线性原图。工具在明确的预览视图下比较统计信息，拟合有限的全局曝光（自动 ±2 档）、对比度和通道平衡，然后直接在场景线性 DWG 中施加曝光/冷暖/饱和度、在 Intermediate 亮度上应用固定黑白端点及 18% 灰锚点的单调受约束对比度曲线，最后编码回 Intermediate。手动曝光为 ±4 档；强度在 Intermediate 编码值中混合，0% 恒等。

这仍是统计原型，不做语义肤色保护、局部照明或镜头跟踪。自动曝光是参考显示统计引导的启发式值，不是对拍摄现场曝光的准确测量。

LUT 及输入数据域限定为 **Intermediate 编码 RGB [0,1]**，不支持负码值和超范围码值；编码 1 对应约 100 的场景线性值，而不是显示白 1。对合法 HDR 范围不会先裁剪到场景线性 1。增益/饱和度仍可能产生低于 0 或超过上限的输出，这些值会受 LUT 域限制，manifest 记录边界比例；该比例也含合法纯黑/端点，不直接等于裁剪比例。需要负值/超范围处理的镜头仍需后续扩展，不应声称当前 LUT 对全部 DWG 浮点数据无损。

输入 uint16 按 **0..65535 全范围**归一化；float32/64 与开发用 float NPY 按 0..1 编码解释。只支持单帧、正向、交错三通道 RGB TIFF，无 alpha、无显示 ICC。建议未压缩 TIFF；特殊压缩 codec 不在当前依赖中。sRGB 加载器明确拒绝高位深 TIFF，防止 Pillow 隐式降为 8 位。参考图 ICC 仍按旧流程转换到 sRGB。

33³ LUT 是采样近似。预览始终回读最终文件，依次评估调色 LUT 与显示 LUT；不以未采样算法冒充 LUT 效果。

## 规范和独立验证依据

- [Blackmagic Design Wide Gamut / Intermediate 信息文档](https://documents.blackmagicdesign.com/InformationNotes/DaVinci_Resolve_17_Wide_Gamut_Intermediate.pdf)：官方原始规范地址；本轮云端请求被代理 403 拒绝，未宣称已读该 PDF。
- 实际核对了 Colour Science 引用同一规范的实现，固定源码提交 `248121e33fcae458e62190ac872f3e16ab2044bf`：
  - [Intermediate 常数和传递函数](https://github.com/colour-science/colour/blob/248121e33fcae458e62190ac872f3e16ab2044bf/colour/models/rgb/transfer_functions/davinci_intermediate.py)
  - [DWG 原色与矩阵](https://github.com/colour-science/colour/blob/248121e33fcae458e62190ac872f3e16ab2044bf/colour/models/rgb/datasets/davinci_wide_gamut.py)
- 已与安装的 **colour-science 0.4.6** 独立实现比较 1024+ 传递函数样本及矩阵；0.18 线性灰编码约 0.336043272384855。运行时不依赖 Colour Science；它只用于开发验证。
