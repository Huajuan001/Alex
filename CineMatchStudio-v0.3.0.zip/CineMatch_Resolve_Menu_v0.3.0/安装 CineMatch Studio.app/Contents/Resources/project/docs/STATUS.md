# 当前交付：v0.3.0 DWG / Intermediate 实验版

本轮在原 sRGB 模式之外增加真正的 **DWG/Intermediate 输入 → DWG/Intermediate 输出** 调色 LUT，放在输出显示变换前；调色运算不经过 sRGB 显示裁剪。另导出自有显示 View LUT 用于预览和诊断，与 Resolve DRT 不同。原生相机 Log 仍需按准确色域/曲线先转换到 DWG，本轮未增加相机专用预设。

- **101 passed、0 failed、0 skipped**：Linux CPython 3.11.17、NumPy 2.2.6、Pillow 12.3.0、Qt Essentials 6.8.3、tifffile 2025.6.11；Colour Science 0.4.6 用于独立数值对照，Lupa 用于 Lua 兼容测试。
- 验证 Intermediate 发布中灰数值、1024+ 独立传递函数样本、DWG 矩阵、编解码往返、线性一档曝光翻倍、高于显示白的 HDR 保留、0/30/70/100% 强度、灰阶单调性、恒等 33³、双 LUT 序列化预览一致性。
- 高精度 RGB16/浮点 TIFF 和 float NPY 已运行；拒绝误标的 8-bit、越界、非有限、alpha、多帧、显示 ICC 数据；补上 sRGB 加载器对高精度 TIFF 的提前识别，避免 Pillow 隐式降为 8 位或给出不清楚的格式错误。
- GUI 已实际以 DWG 示例生成，控件包含模式及曝光档位，禁用 DWG 模式中的 sRGB 亮度偏移。生成/诊断操作固定在滚动区外，保留可见性测试。
- 三种强度的 256×384 合成 DWG 校准图均实际导出。场景线性峰值分别约 32.51、33.21、33.74，超过显示白 1 仍保留；这些数据不是电影画面审美验收。
- 双架构 macOS 新增依赖的固定哈希解析通过；`pip check` 与 ShellCheck 通过。v0.2.0 升级及旧版本备份已测试。

**本机仍待验收**：Mac 安装/菜单启动、真实三类场景、Resolve 21 的 LUT 插值与输出一致性、节点原始帧读取及自动应用。当前不调用未经文档核验的 Resolve API。负/超范围 Intermediate 编码不受此 [0,1] LUT 支持；大幅调整仍可能触及域边界，不能宣称对任意 DWG 数据无损。

下一步用户操作：下载 v0.3.0 包，双击安装；在菜单窗口选择 DWG 模式，先加载包内 DWG 校准源图和 sRGB 参考图试跑，再按 `DWG_WORKFLOW.md` 在测试工程中将调色 LUT 放到 DWG 节点、输出转换之前。保留正确的相机输入解释，避免重复 CST。需要逐像素验收时用随附 View LUT 替代其他输出变换，或仅导出调色后的原编码 DWG TIFF。可提供静帧、项目色彩管理设置和“保存 Resolve 诊断信息”的报告继续本机对接。

详细节点顺序、色彩数学来源及限制见 [DWG_WORKFLOW.md](DWG_WORKFLOW.md)。以下为先前轮次的历史记录，sRGB 专用限制只适用于当时版本或当前 sRGB 模式。

---

# 本轮交付状态（2026-10-19）

## 验证环境与结果

- 云端 Linux x86_64；目标 macOS / Resolve 21 Studio 不在当前机器上。
- 原始项目：2 个测试通过，无既有测试失败；主要缺口为输入校验、完整工作流与覆盖率。
- 修改后：CPython 3.11.17 **44 passed**，CPython 3.12.14 **44 passed**，均包含 2 项 PySide6 离屏集成测试，无失败或跳过。
- Python 3.11 `pip check`：No broken requirements found。具体依赖记录于 `requirements-tested-py311.txt`，这是 Linux 验证记录，未宣称 macOS wheel 或最低系统版本已验证。日常安装使用 README 中的 requirements 文件。
- CLI 实际生成 33³ LUT、sRGB PNG 预览、左右对比图和 manifest；合成图 30/70/100% 均运行。CLI 70% 输出与同参数示例逐像素一致，最大误差 0；这不是 Resolve 对比结果。
- GUI 窗口实际创建，后台生成成功，分割显示 0/50/100% 可绘制；缺失文件错误会恢复控件。截图 `output/demo/ui-smoke.png` 来自 Linux offscreen，不代表 macOS 原生样式。
- Resolve 文档定位工具在 Linux 上执行，两个 Mac 标准位置均不存在；未连接 Resolve、未验证任何 API。

## 阶段 1：基础引擎

已实现图片加载（EXIF、ICC→sRGB）、稳健统计匹配、强度、同源 LUT 预览、33³ R-fastest 导出。测试覆盖完整恒等 LUT、通道顺序、全部六种四面体路径、边界、非有限/越界数据、常量图、错误文件和输出覆盖输入保护。

未完成验收：真实室内人物、城市夜景、自然风景，以及 Resolve 实际输出。

本机下一步：运行 README 的安装/测试命令，用三类有权使用的真实图片按 `LOCAL_VALIDATION.md` 验收。

## 阶段 2：算法控制

已实现受约束的全局编码亮度跨度/中心估计、独立通道平衡、对比度、冷暖和饱和度控制，限定输入输出 sRGB。强度 0 旁通所有控制。

未完成：场景线性曝光估计、多空间/Log/DWG 工作流、感知匹配、非线性柔和高光曲线、语义肤色保护。当前算法仍可能裁剪高光或改变肤色，不视为专业电影迁移；不能依据合成数据证明美学质量。

本机下一步：先看真实图的高光、肤色、暗部和噪声问题，保留参数和对比图，再据实调整下一轮算法目标。

## 阶段 3：桌面界面

已实现 PySide6 图片选择、参考图显示、匹配参数、拖动前后对比、输出目录选择、后台生成与错误提示。CLI 核心无需安装 Qt。所有计算由同一个引擎执行，不另写 UI 算法。

未完成：macOS 原生交互/Retina/权限/窗口布局验收，应用打包、签名、公证。超大图完整输出仍有内存压力；不是实时视频调色工具。

本机下一步：`python -m ui.app`，选择图片生成结果，检查界面显示与导出文件。若有问题，保留完整报错和 macOS 版本。

## 阶段 4：Resolve

已交付本机 Developer Documentation/模块路径发现工具、静帧误差检测 CLI，以及明确色彩空间和插值条件的手动加载 LUT 工作流。

未完成：读取本机 21 Studio 文档、连接探针、当前帧导出、刷新 LUT、自动节点操作及 Python/Resolve 实际一致性验证。未假设任何相关 API 可用。

本机下一步：运行 `python -m resolve.inspect_local`，查看/提供相关开发文档条目；先手动应用 LUT 并导出原尺寸 sRGB 静帧，用 `python -m resolve.compare_render` 比较。详见 `LOCAL_VALIDATION.md`。

## 文件交付

上传的原 ZIP 保留不变。项目在 `/workspace/CineMatchStudio`，未提交或推送到 GitHub。交付压缩包包含源码、测试、文档、测试依赖记录和合成示例；不包含虚拟环境、缓存或外部授权媒体。

## 后续交付：Resolve 脚本菜单启动版 v0.2.0

根据用户希望直接从达芬奇脚本菜单启动的要求，新增 macOS 图形安装器与标准 Lua 菜单入口。首次安装自动准备独立 Python 和固定哈希的 Qt Essentials/NumPy/Pillow，之后无需用户输入终端命令。入口打开共享引擎的独立窗口，当前帧和节点操作继续采用手动工作流。界面可一键保存本机开发文档诊断 JSON。

本轮完整测试：Linux CPython 3.11 / NumPy 2.2.6 / Qt Essentials 6.8.3，**65 passed、0 failed、0 skipped**；ShellCheck 通过。新测试涵盖真实 Bash 启动器、Lua 5.1/5.4、用户路径转义、重复安装、用户文件保护、两类失败回退、损坏运行时校验拒绝、安装包结构和 GUI 诊断导出。原先 44 项结果是上一轮基线，本轮数量增加。

已实际下载 Apple Silicon 和 Intel 的 macOS Python 运行时并核对官方 SHA256SUMS；下载两架构依赖 wheel 并通过固定哈希依赖解析。这些是工件及安装逻辑验证，不等于在 Mac 上执行了安装或运行时。

仍待本机：macOS 13+ 的未签名应用打开流程、安装器实际执行、Resolve 21 菜单识别及窗口启动。尚未读取本机 Resolve 21 文档、连接 Resolve 或验证当前帧/节点 API；没有将这些能力标记为完成。网站 gan.cool 的参考页面在云端返回代理 403，未用于推断其具体插件实现。

本机下一步：解压新包，打开“安装 CineMatch Studio.app”，等待完成后重开 Resolve，从脚本菜单启动。详细步骤见 `macos/README.md`。使用“保存 Resolve 诊断信息”后，提供报告及 Resolve 确切版本，作为下一阶段 API 开发依据。
