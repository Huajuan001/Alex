# sRGB 模式本机验收与 Resolve 回退流程

DWG / Intermediate 模式请先阅读 [DWG_WORKFLOW.md](DWG_WORKFLOW.md)，不要使用本页的 sRGB 调色 LUT 节点位置。

## 1. Python 与界面（不需要 Resolve）

按 README 在 macOS / Python 3.11 建立环境并运行测试。若 PySide6 没有适配当前 macOS 的 wheel，请保留完整安装报错，不要禁用 TLS 或校验。先用核心依赖和 CLI 完成算法验收。

准备自己有使用权的三组图：室内人物、城市夜景、自然风景，每组包含源画面和风格参考。先转换/确认显示 sRGB 编码；不要把相机 Log 静帧直接当 sRGB。UI 选择图片，分别生成 30%、70%、100%，每次选择不同输出目录。检查肤色、暗部、亮部裁剪、色相突变及噪声放大。参考图不需要同尺寸。检查拖动分割线两端分别显示完整结果/原图，改变参数后重新生成，确认导出路径。

记录每组源图编码、参考图编码、参数和观察结果。合成图测试通过不能替代这一步。

## 2. Resolve 手动 LUT 验证

先使用独立测试项目或时间线，保存工作。所有步骤均为手动操作，不依赖未核验的 API。

1. 导入与 Python 使用的**同一张源静帧**。原始相机片段若尚未经过同样的显示变换，不是有效对比输入。
2. 按本机 Resolve 21 Color Management 文档建立明确的 **sRGB 输入 → LUT → sRGB 输出** 测试路径。排除自动输入检测、额外 LUT、自动色彩管理造成的重复变换。若以 DWG 工作，LUT 前后需有明确的编码转换；不要用普通 Rec.709 Gamma 2.4 代替 sRGB。请记录项目设置、输入解释、节点变换及输出标签；无法确认时先停止一致性结论。
3. 通过 Resolve 的 LUT 文件夹设置打开 LUT 目录，复制导出的 `.cube`，在界面刷新 LUT 列表，并在测试节点手动加载。具体菜单名称以本机 21 Studio 文档为准。
4. 若本机提供 LUT 插值选项，设为 **Tetrahedral / 四面体**。Python 使用相同方式。不要以监视器/GUI 截屏做像素比较。
5. 按源尺寸导出 8-bit PNG/TIFF 静帧。保持相同 sRGB 编码，禁用缩放、锐化、水印及其他调色。确认导出 ICC/标签与实际编码一致。
6. 在项目根目录执行：

   ```bash
   python -m resolve.compare_render output/my_shot/previews/preview.png /path/resolve_export.png
   ```

   工具输出 MAE、RMSE、最大和 P99 误差，默认最大误差阈值为 `2/255`，超出返回 1；读取错误或尺寸不一致返回 2。该阈值是初始验收标准，不是已测得的 Resolve 精度。失败先检查色彩管理、插值、标签和导出量化，不能直接归因于算法。

对三类真实场景及 30/70/100% 强度重复检查，保留报告和项目设置。核心自动测试只证明 Python 内部一致性；尚无真实 Resolve 对比结果。

## 3. 查看本机 Developer Documentation

```bash
python -m resolve.inspect_local > resolve_local_inventory.json
```

若未找到，在本机 Resolve 的帮助/开发者资料中查找安装文档，然后：

```bash
python -m resolve.inspect_local --root '/实际的 Developer 目录' > resolve_local_inventory.json
```

工具只查找文档及模块路径，不调用 API、不改项目、不证明 Resolve 版本或 Studio 授权。请提供本机的确切版本、文档中关于连接、当前帧导出、LUT 刷新及节点操作的相关条目。读取本机文档后，下一阶段才编写对应的只读连接探针，再逐项验证写入能力。

在此之前：从 Resolve 手动导出当前帧 → CLI/UI 匹配 → 手动复制并加载 LUT。即使未来自动化失败，也保留此流程。不要把任何凭据、私人媒体或未授权剧照提交到项目。
