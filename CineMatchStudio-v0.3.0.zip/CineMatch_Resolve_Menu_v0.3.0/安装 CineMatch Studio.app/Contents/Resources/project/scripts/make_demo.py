"""Deterministic synthetic calibration fixture, NOT a real-film quality test."""
from pathlib import Path
import numpy as np
from core.images import save_image
from core.lut_generator import generate
from core.matching import MatchSettings


def main():
    root = Path('output/demo')
    y, x = np.mgrid[0:256, 0:384]
    x, y = x/383, y/255
    source = np.stack([x, y, .15+.7*(1-x)*y], axis=-1)
    reference = np.clip(source*np.array([1.06, .95, .85])+.025, 0, 1)
    save_image(source, root/'source.png')
    save_image(reference, root/'reference.png')
    for strength in [.3, .7, 1.]:
        generate(root/'source.png', root/'reference.png', root/f'strength_{int(strength*100)}',
                 MatchSettings(strength=strength))
    print('Synthetic fixture exported at output/demo; real scene acceptance remains pending.')


if __name__ == '__main__':
    main()
