"""Synthetic full-range DWG calibration chart, not real scene/film acceptance."""
from pathlib import Path
import numpy as np
import tifffile
from core.color_spaces import SRGB_TO_DWG, intermediate_encode, dwg_to_display
from core.dwg_images import load_dwg
from core.images import save_image
from core.cube import sample_transform, apply_lut


def create_inputs(root):
    root = Path(root)
    root.mkdir(parents=True, exist_ok=True)
    x = np.geomspace(.001, 32, 384)
    balance = np.ones((256, 3))
    balance[64:128] = [1., .65, .5]
    balance[128:192] = [.55, 1., .65]
    balance[192:] = [.5, .65, 1.]
    linear_srgb = balance[:, None, :]*x[None, :, None]
    encoded = intermediate_encode(linear_srgb @ SRGB_TO_DWG.T)
    source, reference = root/'source_DWG_Intermediate_RGB16.tiff', root/'reference_sRGB.png'
    tifffile.imwrite(source, np.rint(encoded*65535).astype('uint16'), photometric='rgb', metadata=None)
    display = apply_lut(load_dwg(source), sample_transform(dwg_to_display))
    save_image(np.clip(display*np.array([1.04, .97, .90])+.015, 0, 1), reference)
    (root/'示例说明.txt').write_text('程序生成的校准图，非电影画面。源图为全范围 DWG/Intermediate RGB16 TIFF，参考图为 sRGB。\n'
        '在界面选择 DWG 模式后加载这两张图。顶部中性灰阶包含高于显示白的场景线性亮度。\n'
        '调色 LUT 为 DWG→DWG；View LUT 仅用于显示验收，不能与其他输出变换叠加。\n', encoding='utf-8')
    return source, reference


def main():
    from core.lut_generator import generate
    from core.matching import MatchSettings
    root = Path('output/dwg_demo')
    source, reference = create_inputs(root/'inputs')
    for strength in [.3, .7, 1.]:
        generate(source, reference, root/f'strength_{int(strength*100)}', MatchSettings(strength=strength), mode='dwg')
    print(root)


if __name__ == '__main__':
    main()
