# CineMatch Studio — Codex 工作指令

## 项目目标
为 DaVinci Resolve 21 Studio（macOS）开发电影参考图色彩匹配工具。V1 优先完成：导入源画面和电影参考图、色彩匹配、前后预览、导出标准 .cube LUT、在 Resolve 节点手动加载并验证；之后再探索当前帧读取和自动节点应用。电影截图检索不属于 V1。

## 技术环境
- macOS、DaVinci Resolve 21 Studio
- Python 3.11、NumPy、Pillow、OpenCV、PySide6；OpenColorIO 可按需要加入
- 本地 Python 工具优先，验证算法后再探索 Resolve Workflow Integration

## 开发原则
1. 不得将简单 RGB 统计匹配宣传为高质量电影风格迁移。
2. 显式记录输入/输出色彩空间和 LUT 适用位置。测试原型仅处理同一显示参考 RGB 空间中的图像；不能直接将其套入 DWG/Intermediate 节点。
3. 先验证 .cube 顺序、预览与 Resolve 实际输出一致，再优化算法。
4. 不得假设 Resolve API 支持某项操作；先查看本机 Developer Documentation，再写探针脚本。
5. 自动化失败时必须提供手动导入当前帧、手动应用 LUT 的回退方案。
6. 优先做可运行的最小闭环，包含单元测试和明确错误提示。
7. 电影截图检索及第三方图库必须遵守版权和许可，不擅自批量抓取。

## 第一阶段任务
- 检查运行环境，安装 requirements.txt
- 实现源图/参考图加载、稳健基础色彩匹配、预览输出、33³ LUT 导出
- 增加 LUT 恒等映射、顺序和输入范围测试
- 使用真实图像验证与 Resolve 21 Studio 中的 LUT 效果一致
- 汇报局限性并规划色彩管理、肤色保护与高级匹配算法
