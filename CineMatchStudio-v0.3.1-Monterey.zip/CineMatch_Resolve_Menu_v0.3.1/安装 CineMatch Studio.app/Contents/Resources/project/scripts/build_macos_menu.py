"""Build inspectable macOS script-app installer ZIP, without claiming Mac validation."""
import argparse
import hashlib
from pathlib import Path
import plistlib
import shutil
import tempfile
import zipfile

from macos.install import plist, VERSION

QUICKSTART = f'''CineMatch Studio · Resolve 脚本菜单版 v{VERSION}

1. 双击“安装 CineMatch Studio.app”。首次安装需要联网，约 180–250 MB。
2. 等待“安装完成”提示后，完全退出并重新打开 DaVinci Resolve。
3. 打开“工作区 → 脚本 → CineMatch Studio”（也可能分组在 Utility 中）。
4. 选择工作空间、源图和参考图，生成预览和 33³ LUT。
   sRGB 模式用于普通图片；DWG 模式仅用于真正编码为 DWG/Intermediate 的高精度文件。

无需手动安装 Python，也无需终端命令。此版目标为 macOS 12 Monterey 及以上，支持 Apple Silicon / Intel。
此开发测试版尚未签名/公证；如系统阻止，请按 macOS 提供的“打开”或“隐私与安全性 → 仍要打开”流程处理。

菜单启动的是独立调色窗口；当前帧导出和节点 LUT 加载仍为手动操作。
新增 DWG/Intermediate 工作模式：源图使用真正的 DWG RGB16/浮点 TIFF，参考图仍为 sRGB。
DWG 调色 LUT 放在输出变换之前；相机 Log 先用正确的 CST 转到 DWG/Intermediate。
预览使用 CineMatch 自有显示变换；随附 View LUT 只用于显示验收，不能与其他输出变换叠加。
已修复旧版 macOS 13 门槛，静态检查 Intel 运行时和依赖的最低部署系统；尚未在 Mac 上实际运行。
Resolve 本身能否运行取决于它的版本、操作系统和硬件要求，与本安装器的兼容范围不同。

可先用包内“DWG 示例”的两张校准图试跑，选择 DWG 模式；示例不是电影匹配质量验证。
默认输出在“图片 / Pictures → CineMatch Studio”。安装后可删除本下载目录。
遇到错误：Finder“前往 → 前往文件夹”，输入 ~/Library/Logs/CineMatchStudio 查看日志。
界面内可点击“保存 Resolve 诊断信息”，供下一阶段核验本机脚本接口。

更多说明、可审查源码在安装器包的 Contents/Resources/project/macos/README.md。
'''


def build(project, output):
    output.mkdir(parents=True, exist_ok=True)
    archive = output/f'CineMatch_Resolve_Menu_v{VERSION}.zip'
    with tempfile.TemporaryDirectory(prefix='cinematch-release-') as temp:
        release = Path(temp)/f'CineMatch_Resolve_Menu_v{VERSION}'
        release.mkdir()
        (release/'先看这里.txt').write_text(QUICKSTART, encoding='utf-8')
        from scripts.make_dwg_demo import create_inputs
        create_inputs(release/'DWG 示例')
        app = release/'安装 CineMatch Studio.app'
        contents = app/'Contents'
        executables, resources = contents/'MacOS', contents/'Resources'
        executables.mkdir(parents=True)
        resources.mkdir()
        data = plist('安装 CineMatch Studio', 'CineMatchInstaller', 'studio.cinematch.installer')
        data['LSUIElement'] = True
        with (contents/'Info.plist').open('wb') as f:
            plistlib.dump(data, f)
        launcher = executables/'CineMatchInstaller'
        launcher.write_text('#!/bin/bash\nset -eu\nresources="$(cd "$(dirname "$0")/../Resources" && pwd)"\n'
                            'exec /bin/bash "$resources/project/macos/install.sh"\n')
        launcher.chmod(0o755)
        target = resources/'project'
        target.mkdir()
        for name in ('core', 'ui', 'resolve', 'macos', 'scripts', 'tests', 'docs'):
            shutil.copytree(project/name, target/name, ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
        for name in ('AGENTS.md', 'README.md', 'requirements.txt', 'requirements-ui.txt', 'requirements-dev.txt'):
            shutil.copyfile(project/name, target/name)
        with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as z:
            # Include directories and Unix executable bits for Finder extraction.
            z.write(release, release.name+'/')
            for path in sorted(release.rglob('*')):
                z.write(path, path.relative_to(release.parent))
        with zipfile.ZipFile(archive) as z:
            if z.testzip() is not None:
                raise RuntimeError('Corrupt release archive')
    checksum = hashlib.sha256(archive.read_bytes()).hexdigest()
    archive.with_suffix('.zip.sha256').write_text(checksum+'  '+archive.name+'\n')
    return archive


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output', type=Path, default=Path('dist'))
    args = p.parse_args()
    print(build(Path(__file__).resolve().parents[1], args.output))


if __name__ == '__main__':
    main()
