"""Guard the OS metadata/installer agreement which blocked Monterey users."""
import struct
import subprocess
import zipfile
from pathlib import Path
import pytest
from macos.install import MINIMUM_MACOS, VERSION, plist
from scripts.audit_macos_artifacts import macho_targets, audit

PROJECT = Path(__file__).resolve().parents[1]

@pytest.mark.parametrize('version,accepted', [('12.0', True), ('12.7.6', True), ('13.0', True),
    ('14.7', True), ('15.0', True), ('26.0', True), ('11.7.10', False), ('10.15.7', False),
    ('', False), ('unknown', False)])
def test_bootstrap_os_guard_accepts_monterey(version, accepted):
    command = 'source "$1"; supports_macos_version "$2"'
    result = subprocess.run(['bash', '-c', command, 'test', str(PROJECT/'macos/install.sh'), version],
                            capture_output=True, text=True)
    assert (result.returncode == 0) is accepted


def test_installer_and_application_share_monterey_metadata():
    info = plist('test', 'launcher', 'studio.cinematch.test')
    assert info['LSMinimumSystemVersion'] == MINIMUM_MACOS == '12.0'
    assert info['CFBundleShortVersionString'] == VERSION == '0.3.1'


def thin(version=(12, 0, 0), cpu=0x01000007, subtype=3, old=False):
    packed = (version[0]<<16) | (version[1]<<8) | version[2]
    cmd = struct.pack('<IIII', 0x24, 16, packed, packed) if old else struct.pack('<IIIIII', 0x32, 24, 1, packed, packed, 0)
    header = b'\xcf\xfa\xed\xfe'+struct.pack('<IIIIIII', cpu, subtype, 6, 1, len(cmd), 0, 0)
    return header+cmd


@pytest.mark.parametrize('old', [False, True])
def test_parse_macos_load_commands(old):
    records = macho_targets(thin((12, 7, 6), old=old))
    assert records == [{'arch':'x86_64', 'cpu_subtype':3, 'minimum_macos': (12, 7, 6)}]


def test_parse_universal_slices():
    intel, arm = thin(), thin((11, 0, 0), cpu=0x0100000C, subtype=0)
    offset = 8+2*20
    header = b'\xca\xfe\xba\xbe'+struct.pack('>I', 2)
    header += struct.pack('>IIIII', 0x01000007, 3, offset, len(intel), 0)
    header += struct.pack('>IIIII', 0x0100000C, 0, offset+len(intel), len(arm), 0)
    records = macho_targets(header+intel+arm)
    assert [r['arch'] for r in records] == ['x86_64', 'arm64']
    assert records[1]['minimum_macos'] == (11, 0, 0)


def test_audit_rejects_too_new_and_unknown_targets(tmp_path):
    wheel = tmp_path/'sample.whl'
    with zipfile.ZipFile(wheel, 'w') as z:
        z.writestr('QtCore', thin((13, 0, 0)))
    report = audit(wheel)
    assert not report['compatible_deployment_targets'] and report['incompatible']
    with zipfile.ZipFile(wheel, 'w') as z:
        z.writestr('QtCore', b'\xcf\xfa\xed\xfe'+struct.pack('<IIIIIII', 0x01000007, 3, 6, 0, 0, 0, 0))
    assert audit(wheel)['unknown_targets'] == ['QtCore']
    with pytest.raises(ValueError, match='Truncated'):
        macho_targets(thin()[:-1])
