# Resolve 脚本菜单版 v0.3.1（待 Mac 实机验收）

目标：首次双击安装，之后从 Resolve 的脚本菜单打开 CineMatch 调色窗口。用户无需手动配置 Python、pip 或终端。

## 用户操作

1. 解压 `CineMatch_Resolve_Menu_v0.3.1.zip`。
2. 打开 `安装 CineMatch Studio.app`。此开发测试版尚未签名/公证；如 macOS 阻止，按系统提供的“打开”或“系统设置 → 隐私与安全性 → 仍要打开”流程处理。不要求关闭系统安全保护。
3. 确认安装，等待完成提示。首次联网下载约 180–250 MB，包括独立 Python、NumPy、Pillow、Qt Essentials。需要可访问 GitHub 发布下载及 PyPI。
4. 重新打开 Resolve，查找「工作区 / Workspace → 脚本 / Scripts → CineMatch Studio」。若菜单按文件夹分组，查看 Utility。该位置仍待 Resolve 21 实机确认。
5. 选择工作空间模式，再选择源图、参考图和匹配强度，生成前后预览及 33³ LUT。默认结果存于用户 `Pictures/CineMatch Studio`；可自行改输出目录。

macOS 12 Monterey 及以上，Apple Silicon / Intel 两种架构。安装器为脚本应用包，云端没有执行过 macOS LaunchServices/Gatekeeper，因此首次打开及菜单识别属于本机待验收项，而非已保证兼容。

## Monterey 12.7.6 / Intel 修复说明

v0.3.0 的安装器与应用 `LSMinimumSystemVersion` 都设为 `13.0`，安装脚本也拒绝 macOS 12，会造成 Finder 禁止图标。v0.3.1 将三处统一为 `12.0` / 12，应用构建号升级为 4，保留 Intel 架构自动选择。

实际下载的 Python、NumPy、Pillow、Qt Essentials 和 shiboken6 已核验 SHA256，并检查 270 个 Intel Mach-O 切片的最低系统字段，没有高于 macOS 12.0 的依赖；详见 `docs/MONTEREY_COMPATIBILITY.md`。这不是已在 Monterey 上运行成功的声明。

请打开新解压的 **v0.3.1** 文件夹里的安装器，旧包不会自动改变。Monterey 若提示未认证开发者，可使用右键“打开”，或“系统偏好设置 → 安全性与隐私 → 通用”中系统提供的打开选项；不要求关闭 Gatekeeper。当前对接本机实际安装的 Resolve 19.1；菜单入口未调用 21 专属 API。Resolve 自身的系统和硬件兼容性仍与工具的 macOS 12 门槛分开判断。

## 体验边界

此版是**Resolve 脚本菜单入口 + 独立调色窗口**。Lua 仅使用标准库，通过 macOS `open` 启动应用；不调用 Resolve/Fusion API。当前帧读取和节点应用仍采用手动导出/加载流程，窗口不是 Resolve 内嵌面板。

新增 DWG/Intermediate 模式：高精度 DWG 源图、sRGB 参考图，生成 DWG→DWG 调色 LUT，放在输出变换前。原 sRGB 模式仍只用于显示 sRGB。相机原生 Log 须先正确转换到 DWG。预览采用自有显示变换，随附 View LUT 仅用于显示验收，不能和其他输出变换叠加。完整工作流见 `docs/DWG_WORKFLOW.md`。包内包含可试跑的合成 DWG 校准图。

界面新增「保存 Resolve 诊断信息」，可通过文件对话框保存 JSON。该报告只查找本机 Developer Documentation 路径和有关方法的文档条目，不调用方法、不修改项目，也不证明方法在本机实际可用。将此报告连同 Resolve 确切版本反馈后，再根据文档开发只读连接/当前帧探针。这样下一阶段也无需你运行终端命令。

## 故障处理

- 安装/启动错误会显示日志位置：`~/Library/Logs/CineMatchStudio/install.log` 和 `runtime.log`。Finder 的「前往 → 前往文件夹」可直接打开该目录。
- 脚本菜单里没有入口：先确认安装完成，完全退出并重开 Resolve，再检查 Utility 分组；提供 Resolve 版本及菜单截图。
- 下载受限：检查 GitHub、release-assets.githubusercontent.com、pypi.org、files.pythonhosted.org 的网络访问后重试。安装器不会关闭 TLS、哈希校验或要求管理员密码。
- 同名第三方脚本/应用存在：安装器拒绝覆盖，需先在 Finder 中确认并改名。可从 v0.2.0 升级；重装本工具时，旧应用与菜单脚本备份在安装根目录的 `backups`。
- 未完成的下载会清理本次暂存目录；完成的运行时和依赖保留以便重试。若遇到不完整运行时/残留安装锁，提供日志，避免直接删除未知目录。

## 技术与验证记录

- 独立运行时：astral-sh/python-build-standalone `20261013` / CPython `3.11.17`，已下载两个 Mac 架构并核对官方 `SHA256SUMS`，检查了 `python/bin/python3` 入口。
- Apple Silicon SHA256：`5e656e09fc73c7ae10e4df66e6aa253f1f5980509b3be8a242e883d67a5fdf26`
- Intel SHA256：`a870f5bb476ebe4483761ffdcd39b316dbef9f59f158706296d2c6f138057cae`
- 运行依赖：NumPy 2.2.6、Pillow 12.3.0、tifffile 2025.6.11、PySide6-Essentials / shiboken6 6.8.3；只装 QtCore/QtGui/QtWidgets 所需的 Essentials，不装 WebEngine/Addons。双架构 wheel 均已下载并进行 `--require-hashes` 依赖解析，固定于 `plugin-requirements.lock`。
- 应用启动时清理继承的 Python/Qt 插件路径，避免 Resolve 自带库干扰；不改 Resolve 或系统设置。
- 安装位置：`~/Library/Application Support/CineMatchStudio/`；菜单脚本：`~/Library/Application Support/Blackmagic Design/DaVinci Resolve/Fusion/Scripts/Utility/CineMatch Studio.lua`。
- Lua 5.1 / 5.4：已执行缺失安装、成功启动、启动失败及含空格/引号用户路径测试。
- 安装逻辑：已测试重复安装备份、拒绝覆盖第三方文件、写入与备份失败回退、真实 Bash 启动器参数及损坏下载拒绝。
- Linux CPython 3.11 / Qt Essentials 6.8.3：完整测试结果记录于 `docs/STATUS.md`。这些测试不等于 macOS 安装和 Resolve 21 实机验收。

开发构建：`python -m scripts.build_macos_menu --output /path/to/release`。构建脚本生成可检查的 shell `.app` 包，不进行签名/公证，不打包 macOS 二进制运行时；首次安装时按固定校验值下载。
